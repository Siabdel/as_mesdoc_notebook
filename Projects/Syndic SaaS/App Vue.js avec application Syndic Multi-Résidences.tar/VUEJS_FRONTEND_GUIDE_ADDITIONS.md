# Compléments au Guide Frontend Vue.js - Fonctionnalités Avancées

Ce document contient les sections additionnelles pour :

1. **Composants de graphiques financiers**
2. **Système de notifications en temps réel**
3. **Module de messagerie**
4. **Export PDF/Excel**

---

## 1. Composants de Graphiques Financiers

### Installation des dépendances

```bash
# Chart.js pour les graphiques
npm install chart.js vue-chartjs

# Pour les graphiques plus avancés
npm install apexcharts vue3-apexcharts
```

### Configuration dans `src/main.js`

```javascript
import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import { createPinia } from 'pinia'

// Chart.js
import Chart from 'chart.js/auto'
import { registerables } from 'chart.js'

Chart.register(...registerables)

// ApexCharts
import ApexCharts from 'apexcharts'
import VueApexCharts from 'vue3-apexcharts'

const app = createApp(App)
const pinia = createPinia()

app.component('apexchart', VueApexCharts)
app.use(pinia)
app.use(router)
app.mount('#app')
```

### `src/components/finances/FinanceChart.vue`

```vue
<template>
  <div class="finance-chart">
    <canvas ref="chartCanvas"></canvas>
  </div>
</template>

<script setup>
import { ref, onMounted, watch, onUnmounted } from 'vue'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js'
import { Bar, Line, Doughnut, Pie } from 'vue-chartjs'

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
)

const props = defineProps({
  type: {
    type: String,
    default: 'bar', // 'bar', 'line', 'doughnut', 'pie'
    validator: (value) => ['bar', 'line', 'doughnut', 'pie'].includes(value)
  },
  data: {
    type: Object,
    required: true
  },
  options: {
    type: Object,
    default: () => ({})
  }
})

const chartCanvas = ref(null)
let chartInstance = null

const defaultOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'bottom',
      labels: {
        usePointStyle: true,
        padding: 20
      }
    },
    tooltip: {
      backgroundColor: 'rgba(0, 0, 0, 0.8)',
      padding: 12,
      titleFont: { size: 14 },
      bodyFont: { size: 13 },
      callbacks: {
        label: function(context) {
          if (context.parsed.y !== undefined) {
            return `${context.dataset.label}: ${new Intl.NumberFormat('fr-MA', {
              style: 'currency',
              currency: 'MAD'
            }).format(context.parsed.y)}`
          }
          return `${context.label}: ${context.parsed}`
        }
      }
    }
  },
  scales: {
    y: {
      beginAtZero: true,
      ticks: {
        callback: function(value) {
          return new Intl.NumberFormat('fr-MA', {
            style: 'currency',
            currency: 'MAD',
            maximumFractionDigits: 0
          }).format(value)
        }
      }
    }
  }
}

const chartData = computed(() => {
  return {
    labels: props.data.labels || [],
    datasets: props.data.datasets || []
  }
})

const chartOptions = computed(() => {
  return {
    ...defaultOptions,
    ...props.options
  }
})

const createChart = () => {
  if (!chartCanvas.value) return

  const ctx = chartCanvas.value.getContext('2d')
  
  chartInstance = new ChartJS(ctx, {
    type: props.type,
    data: chartData.value,
    options: chartOptions.value
  })
}

const updateChart = () => {
  if (chartInstance) {
    chartInstance.data = chartData.value
    chartInstance.options = chartOptions.value
    chartInstance.update()
  }
}

watch(() => props.data, updateChart, { deep: true })
watch(() => props.options, updateChart, { deep: true })

onMounted(() => {
  createChart()
})

onUnmounted(() => {
  if (chartInstance) {
    chartInstance.destroy()
  }
})
</script>

<style scoped>
.finance-chart {
  position: relative;
  height: 400px;
  width: 100%;
}

@media (max-width: 768px) {
  .finance-chart {
    height: 300px;
  }
}
</style>
```

### `src/components/finances/RecettesDepensesChart.vue`

```vue
<template>
  <div class="recettes-depenses-chart">
    <div class="chart-header mb-4">
      <h5 class="chart-title">
        <i class="bi bi-graph-up me-2"></i>
        Évolution Recettes vs Dépenses
      </h5>
      <select
        v-model="selectedPeriod"
        class="form-select w-auto"
        @change="updateChart"
      >
        <option value="month">Mensuel</option>
        <option value="quarter">Trimestriel</option>
        <option value="year">Annuel</option>
      </select>
    </div>

    <div class="chart-container">
      <FinanceChart
        :type="'line'"
        :data="chartData"
        :options="chartOptions"
      />
    </div>

    <div class="chart-legend mt-3">
      <div class="legend-item">
        <span class="legend-color recettes"></span>
        <span>Total Recettes: {{ formatCurrency(totalRecettes) }}</span>
      </div>
      <div class="legend-item">
        <span class="legend-color depenses"></span>
        <span>Total Dépenses: {{ formatCurrency(totalDepenses) }}</span>
      </div>
      <div class="legend-item">
        <span class="legend-color solde"></span>
        <span>Solde: {{ formatCurrency(solde) }}</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import FinanceChart from './FinanceChart.vue'
import { formatCurrency } from '@/utils/formatters'

const props = defineProps({
  residenceId: {
    type: Number,
    required: true
  },
  year: {
    type: Number,
    required: true
  }
})

const selectedPeriod = ref('month')
const chartData = ref({
  labels: [],
  datasets: []
})

const totalRecettes = computed(() => {
  if (!chartData.value.datasets[0]) return 0
  return chartData.value.datasets[0].data.reduce((a, b) => a + b, 0)
})

const totalDepenses = computed(() => {
  if (!chartData.value.datasets[1]) return 0
  return chartData.value.datasets[1].data.reduce((a, b) => a + b, 0)
})

const solde = computed(() => totalRecettes.value - totalDepenses.value)

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  interaction: {
    mode: 'index',
    intersect: false
  },
  plugins: {
    legend: {
      display: false
    },
    tooltip: {
      backgroundColor: 'rgba(0, 0, 0, 0.8)',
      padding: 12
    }
  },
  scales: {
    y: {
      beginAtZero: true,
      grid: {
        color: 'rgba(0, 0, 0, 0.05)'
      }
    },
    x: {
      grid: {
        display: false
      }
    }
  },
  elements: {
    line: {
      tension: 0.4,
      borderWidth: 3
    },
    point: {
      radius: 4,
      hoverRadius: 6
    }
  }
}

const loadChartData = async () => {
  try {
    // Appel API pour récupérer les données
    const response = await fetch(`/api/residences/${props.residenceId}/finances/evolution/?period=${selectedPeriod.value}&year=${props.year}`)
    const data = await response.json()

    chartData.value = {
      labels: data.labels,
      datasets: [
        {
          label: 'Recettes',
          data: data.recettes,
          borderColor: '#28a745',
          backgroundColor: 'rgba(40, 167, 69, 0.1)',
          fill: true
        },
        {
          label: 'Dépenses',
          data: data.depenses,
          borderColor: '#dc3545',
          backgroundColor: 'rgba(220, 53, 69, 0.1)',
          fill: true
        }
      ]
    }
  } catch (error) {
    console.error('Erreur chargement données graphique:', error)
  }
}

const updateChart = () => {
  loadChartData()
}

onMounted(() => {
  loadChartData()
})
</script>

<style scoped>
.recettes-depenses-chart {
  padding: 20px;
}

.chart-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.chart-title {
  margin: 0;
  font-weight: 600;
  color: #333;
}

.chart-container {
  height: 350px;
  position: relative;
}

.chart-legend {
  display: flex;
  justify-content: center;
  gap: 30px;
  flex-wrap: wrap;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 500;
}

.legend-color {
  width: 12px;
  height: 12px;
  border-radius: 50%;
}

.legend-color.recettes {
  background-color: #28a745;
}

.legend-color.depenses {
  background-color: #dc3545;
}

.legend-color.solde {
  background-color: #007bff;
}

@media (max-width: 768px) {
  .chart-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 15px;
  }

  .chart-legend {
    flex-direction: column;
    gap: 10px;
  }

  .chart-container {
    height: 250px;
  }
}
</style>
```

### `src/components/finances/BudgetRepartitionChart.vue`

```vue
<template>
  <div class="budget-repartition-chart">
    <div class="chart-header mb-4">
      <h5 class="chart-title">
        <i class="bi bi-pie-chart me-2"></i>
        Répartition du Budget
      </h5>
      <div class="chart-toggles">
        <button
          class="btn btn-sm"
          :class="chartType === 'doughnut' ? 'btn-primary' : 'btn-outline-primary'"
          @click="chartType = 'doughnut'"
        >
          <i class="bi bi-circle"></i>
        </button>
        <button
          class="btn btn-sm"
          :class="chartType === 'bar' ? 'btn-primary' : 'btn-outline-primary'"
          @click="chartType = 'bar'"
        >
          <i class="bi bi-bar-chart"></i>
        </button>
      </div>
    </div>

    <div v-if="loading" class="text-center py-5">
      <div class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Chargement...</span>
      </div>
    </div>

    <div v-else class="chart-content">
      <div class="chart-container">
        <FinanceChart
          :type="chartType"
          :data="chartData"
          :options="chartOptions"
        />
      </div>

      <div class="budget-details mt-4">
        <h6 class="details-title">Détail par poste</h6>
        <div class="budget-items">
          <div
            v-for="(item, index) in budgetItems"
            :key="index"
            class="budget-item"
          >
            <div class="item-color" :style="{ backgroundColor: colors[index] }"></div>
            <div class="item-info">
              <span class="item-label">{{ item.categorie }}</span>
              <span class="item-amount">{{ formatCurrency(item.montant) }}</span>
            </div>
            <div class="item-percentage">{{ item.percentage }}%</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import FinanceChart from './FinanceChart.vue'
import { formatCurrency } from '@/utils/formatters'

const props = defineProps({
  residenceId: {
    type: Number,
    required: true
  },
  year: {
    type: Number,
    required: true
  }
})

const loading = ref(true)
const chartType = ref('doughnut')
const budgetItems = ref([])

const colors = [
  '#667eea',
  '#764ba2',
  '#f093fb',
  '#f5576c',
  '#4facfe',
  '#00f2fe',
  '#43e97b',
  '#38f9d7'
]

const chartData = computed(() => ({
  labels: budgetItems.value.map(item => item.categorie),
  datasets: [{
    data: budgetItems.value.map(item => item.montant),
    backgroundColor: colors.slice(0, budgetItems.value.length),
    borderWidth: 2,
    borderColor: '#fff'
  }]
}))

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: false
    },
    tooltip: {
      callbacks: {
        label: function(context) {
          const item = budgetItems.value[context.dataIndex]
          return [
            `${item.categorie}: ${formatCurrency(item.montant)}`,
            `${item.percentage}% du budget`
          ]
        }
      }
    }
  }
}

const loadBudgetData = async () => {
  loading.value = true
  try {
    const response = await fetch(`/api/residences/${props.residenceId}/budgets/${props.year}/repartition/`)
    const data = await response.json()

    const total = data.reduce((sum, item) => sum + item.montant, 0)

    budgetItems.value = data.map(item => ({
      ...item,
      percentage: ((item.montant / total) * 100).toFixed(1)
    }))
  } catch (error) {
    console.error('Erreur chargement budget:', error)
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  loadBudgetData()
})
</script>

<style scoped>
.budget-repartition-chart {
  padding: 20px;
}

.chart-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.chart-title {
  margin: 0;
  font-weight: 600;
  color: #333;
}

.chart-container {
  height: 300px;
  position: relative;
}

.details-title {
  font-weight: 600;
  color: #555;
  margin-bottom: 15px;
}

.budget-items {
  max-height: 400px;
  overflow-y: auto;
}

.budget-item {
  display: flex;
  align-items: center;
  padding: 12px;
  border-bottom: 1px solid #f0f0f0;
  transition: background-color 0.2s;
}

.budget-item:hover {
  background-color: #f8f9fa;
}

.item-color {
  width: 16px;
  height: 16px;
  border-radius: 4px;
  margin-right: 12px;
  flex-shrink: 0;
}

.item-info {
  flex-grow: 1;
  display: flex;
  justify-content: space-between;
}

.item-label {
  font-weight: 500;
  color: #333;
}

.item-amount {
  font-weight: 600;
  color: #555;
}

.item-percentage {
  font-weight: 700;
  color: #667eea;
  margin-left: 15px;
  min-width: 60px;
  text-align: right;
}

@media (max-width: 768px) {
  .chart-container {
    height: 250px;
  }
}
</style>
```

---

## 2. Système de Notifications en Temps Réel

### Installation

```bash
# Socket.io pour les connexions WebSocket
npm install socket.io-client

# Notifications push (optionnel)
npm install @vueuse/core
```

### `src/composables/useNotifications.js`

```javascript
import { ref, onMounted, onUnmounted } from 'vue'
import { io } from 'socket.io-client'
import { useToast } from 'vue-toastification'
import { useAuthStore } from '@/stores/auth'

export function useNotifications() {
  const notifications = ref([])
  const unreadCount = ref(0)
  const socket = ref(null)
  const toast = useToast()
  const authStore = useAuthStore()

  const connect = () => {
    if (!authStore.token) return

    socket.value = io(import.meta.env.VITE_WS_URL || 'http://localhost:8000', {
      auth: {
        token: authStore.token
      },
      transports: ['websocket', 'polling']
    })

    socket.value.on('connect', () => {
      console.log('WebSocket connected')
    })

    socket.value.on('notification', (notification) => {
      notifications.value.unshift(notification)
      unreadCount.value++

      // Show toast notification
      showToast(notification)
    })

    socket.value.on('unread_count', (count) => {
      unreadCount.value = count
    })

    socket.value.on('disconnect', () => {
      console.log('WebSocket disconnected')
    })

    socket.value.on('error', (error) => {
      console.error('WebSocket error:', error)
    })
  }

  const disconnect = () => {
    if (socket.value) {
      socket.value.disconnect()
      socket.value = null
    }
  }

  const markAsRead = (notificationId) => {
    // API call to mark as read
    fetch(`/api/notifications/${notificationId}/read/`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${authStore.token}`
      }
    }).then(() => {
      const notification = notifications.value.find(n => n.id === notificationId)
      if (notification) {
        notification.read = true
        unreadCount.value = Math.max(0, unreadCount.value - 1)
      }
    })
  }

  const markAllAsRead = () => {
    fetch('/api/notifications/read-all/', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${authStore.token}`
      }
    }).then(() => {
      notifications.value.forEach(n => n.read = true)
      unreadCount.value = 0
    })
  }

  const showToast = (notification) => {
    const toastOptions = {
      timeout: 5000,
      closeOnClick: true,
      onClick: () => {
        markAsRead(notification.id)
        if (notification.action_url) {
          window.location.href = notification.action_url
        }
      }
    }

    switch (notification.type) {
      case 'payment_received':
        toast.success(`Paiement reçu: ${notification.message}`, toastOptions)
        break
      case 'payment_overdue':
        toast.error(`Paiement en retard: ${notification.message}`, toastOptions)
        break
      case 'meeting_reminder':
        toast.info(`Rappel AG: ${notification.message}`, toastOptions)
        break
      case 'document_shared':
        toast.info(`Nouveau document: ${notification.message}`, toastOptions)
        break
      case 'maintenance_alert':
        toast.warning(`Alerte maintenance: ${notification.message}`, toastOptions)
        break
      default:
        toast(notification.message, toastOptions)
    }
  }

  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission()
      return permission === 'granted'
    }
    return false
  }

  const showBrowserNotification = (notification) => {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(notification.title, {
        body: notification.message,
        icon: '/favicon.ico',
        badge: '/favicon.ico',
        tag: notification.id
      })
    }
  }

  onMounted(() => {
    connect()
    requestNotificationPermission()

    // Load initial notifications
    fetch('/api/notifications/', {
      headers: {
        'Authorization': `Bearer ${authStore.token}`
      }
    })
      .then(res => res.json())
      .then(data => {
        notifications.value = data.results || data
        unreadCount.value = data.unread_count || 0
      })
  })

  onUnmounted(() => {
    disconnect()
  })

  return {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    connect,
    disconnect
  }
}
```

### `src/components/common/NotificationDropdown.vue`

```vue
<template>
  <div class="notification-dropdown">
    <button
      class="btn btn-link position-relative"
      @click="toggleDropdown"
      ref="dropdownButton"
    >
      <i class="bi bi-bell fs-5"></i>
      <span
        v-if="unreadCount > 0"
        class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"
      >
        {{ unreadCount > 99 ? '99+' : unreadCount }}
      </span>
    </button>

    <div
      v-if="isOpen"
      class="notification-menu dropdown-menu dropdown-menu-end show"
      ref="dropdownMenu"
    >
      <div class="notification-header">
        <h6 class="mb-0">Notifications</h6>
        <button
          v-if="unreadCount > 0"
          class="btn btn-sm btn-link text-decoration-none"
          @click="markAllAsRead"
        >
          Tout marquer comme lu
        </button>
      </div>

      <div class="notification-list">
        <div
          v-if="notifications.length === 0"
          class="text-center py-4 text-muted"
        >
          <i class="bi bi-inbox fs-1 d-block mb-2"></i>
          Aucune notification
        </div>

        <div
          v-for="notification in notifications.slice(0, 10)"
          :key="notification.id"
          class="notification-item"
          :class="{ unread: !notification.read }"
          @click="handleNotificationClick(notification)"
        >
          <div class="notification-icon" :class="`icon-${notification.type}`">
            <i :class="getNotificationIcon(notification.type)"></i>
          </div>
          <div class="notification-content">
            <div class="notification-title">{{ notification.title }}</div>
            <div class="notification-message">{{ notification.message }}</div>
            <div class="notification-time">{{ formatTime(notification.created_at) }}</div>
          </div>
          <div v-if="!notification.read" class="notification-indicator"></div>
        </div>
      </div>

      <div v-if="notifications.length > 10" class="notification-footer">
        <router-link to="/notifications" class="btn btn-link text-decoration-none w-100">
          Voir toutes les notifications
        </router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, onClickOutside } from '@vueuse/core'
import { useNotifications } from '@/composables/useNotifications'
import { formatRelativeTime } from '@/utils/formatters'
import { useRouter } from 'vue-router'

const router = useRouter()
const { notifications, unreadCount, markAsRead, markAllAsRead } = useNotifications()

const isOpen = ref(false)
const dropdownButton = ref(null)
const dropdownMenu = ref(null)

const toggleDropdown = () => {
  isOpen.value = !isOpen.value
}

const handleNotificationClick = (notification) => {
  markAsRead(notification.id)
  isOpen.value = false

  if (notification.action_url) {
    router.push(notification.action_url)
  }
}

const getNotificationIcon = (type) => {
  const icons = {
    payment_received: 'bi bi-cash-coin',
    payment_overdue: 'bi bi-exclamation-circle',
    meeting_reminder: 'bi bi-calendar-event',
    document_shared: 'bi bi-file-earmark',
    maintenance_alert: 'bi bi-tools',
    message: 'bi bi-chat-dots',
    system: 'bi bi-gear'
  }
  return icons[type] || 'bi bi-bell'
}

const formatTime = (date) => {
  return formatRelativeTime(date)
}

// Close dropdown when clicking outside
onClickOutside(dropdownMenu, () => {
  isOpen.value = false
})
</script>

<style scoped>
.notification-dropdown {
  position: relative;
}

.btn-link {
  color: #fff;
  text-decoration: none;
  padding: 8px;
}

.notification-menu {
  position: absolute;
  right: 0;
  top: 100%;
  width: 380px;
  max-height: 500px;
  background: white;
  border-radius: 12px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
  z-index: 1000;
  padding: 0;
  overflow: hidden;
}

.notification-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  border-bottom: 1px solid #f0f0f0;
  background: #f8f9fa;
}

.notification-header h6 {
  font-weight: 600;
  margin: 0;
}

.notification-list {
  max-height: 400px;
  overflow-y: auto;
}

.notification-item {
  display: flex;
  align-items: flex-start;
  padding: 16px 20px;
  border-bottom: 1px solid #f0f0f0;
  cursor: pointer;
  transition: background-color 0.2s;
  position: relative;
}

.notification-item:hover {
  background-color: #f8f9fa;
}

.notification-item.unread {
  background-color: #f0f7ff;
}

.notification-icon {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 12px;
  flex-shrink: 0;
  font-size: 1.2rem;
}

.notification-icon.icon-payment_received {
  background-color: #d4edda;
  color: #28a745;
}

.notification-icon.icon-payment_overdue {
  background-color: #f8d7da;
  color: #dc3545;
}

.notification-icon.icon-meeting_reminder {
  background-color: #d1ecf1;
  color: #17a2b8;
}

.notification-icon.icon-document_shared {
  background-color: #fff3cd;
  color: #ffc107;
}

.notification-icon.icon-maintenance_alert {
  background-color: #f8d7da;
  color: #dc3545;
}

.notification-icon.icon-message {
  background-color: #e2e3e5;
  color: #6c757d;
}

.notification-content {
  flex-grow: 1;
  min-width: 0;
}

.notification-title {
  font-weight: 600;
  font-size: 0.9rem;
  color: #333;
  margin-bottom: 4px;
}

.notification-message {
  font-size: 0.85rem;
  color: #666;
  line-height: 1.4;
  margin-bottom: 4px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.notification-time {
  font-size: 0.75rem;
  color: #999;
}

.notification-indicator {
  width: 8px;
  height: 8px;
  background-color: #007bff;
  border-radius: 50%;
  position: absolute;
  right: 12px;
  top: 20px;
}

.notification-footer {
  padding: 12px 20px;
  border-top: 1px solid #f0f0f0;
  background: #f8f9fa;
}

@media (max-width: 480px) {
  .notification-menu {
    width: calc(100vw - 40px);
    right: -10px;
  }
}
</style>
```

---

## 3. Module de Messagerie

### `src/api/messages.js`

```javascript
import api from './axios'

export const messagesAPI = {
  // Liste des conversations
  getConversations(params = {}) {
    return api.get('/messages/conversations/', { params })
  },

  // Détail d'une conversation
  getConversation(conversationId) {
    return api.get(`/messages/conversations/${conversationId}/`)
  },

  // Messages d'une conversation
  getMessages(conversationId, params = {}) {
    return api.get(`/messages/conversations/${conversationId}/messages/`, { params })
  },

  // Envoyer un message
  sendMessage(conversationId, data) {
    return api.post(`/messages/conversations/${conversationId}/messages/`, data)
  },

  // Créer une nouvelle conversation
  createConversation(data) {
    return api.post('/messages/conversations/', data)
  },

  // Marquer comme lu
  markAsRead(conversationId) {
    return api.post(`/messages/conversations/${conversationId}/read/`)
  },

  // Upload fichier
  uploadFile(conversationId, file) {
    const formData = new FormData()
    formData.append('file', file)
    return api.post(`/messages/conversations/${conversationId}/upload/`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
  },

  // Rechercher des messages
  searchMessages(query) {
    return api.get('/messages/search/', { params: { q: query } })
  }
}
```

### `src/components/messaging/MessageList.vue`

```vue
<template>
  <div class="message-list-container">
    <div class="message-header">
      <h5 class="mb-0">
        <i class="bi bi-chat-dots me-2"></i>
        Messagerie
      </h5>
      <button class="btn btn-primary btn-sm" @click="$emit('new-conversation')">
        <i class="bi bi-plus-lg me-1"></i>Nouvelle
      </button>
    </div>

    <!-- Search -->
    <div class="search-box mb-3">
      <div class="input-group">
        <span class="input-group-text">
          <i class="bi bi-search"></i>
        </span>
        <input
          v-model="searchQuery"
          type="text"
          class="form-control"
          placeholder="Rechercher une conversation..."
          @input="handleSearch"
        >
      </div>
    </div>

    <!-- Conversations -->
    <div class="conversations-list">
      <div
        v-if="loading"
        class="text-center py-4"
      >
        <div class="spinner-border text-primary" role="status"></div>
      </div>

      <div v-else-if="conversations.length === 0" class="empty-state">
        <i class="bi bi-chat-square-text fs-1"></i>
        <p class="text-muted">Aucune conversation</p>
      </div>

      <div
        v-for="conversation in filteredConversations"
        :key="conversation.id"
        class="conversation-item"
        :class="{ active: selectedConversation === conversation.id, unread: conversation.unread_count > 0 }"
        @click="$emit('select', conversation.id)"
      >
        <div class="conversation-avatar">
          <img
            v-if="conversation.participant.avatar"
            :src="conversation.participant.avatar"
            :alt="conversation.participant.name"
          >
          <div v-else class="avatar-placeholder">
            {{ getInitials(conversation.participant.name) }}
          </div>
          <span
            v-if="conversation.participant.online"
            class="online-indicator"
          ></span>
        </div>

        <div class="conversation-content">
          <div class="conversation-header-row">
            <span class="conversation-name">{{ conversation.participant.name }}</span>
            <span class="conversation-time">{{ formatTime(conversation.last_message_at) }}</span>
          </div>
          <div class="conversation-preview">
            <span v-if="conversation.last_message_sender === 'me'" class="me-indicator">
              <i class="bi bi-check2"></i>
            </span>
            <span class="message-text">{{ conversation.last_message }}</span>
          </div>
        </div>

        <div v-if="conversation.unread_count > 0" class="unread-badge">
          {{ conversation.unread_count }}
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { messagesAPI } from '@/api/messages'
import { formatRelativeTime } from '@/utils/formatters'

const props = defineProps({
  selectedConversation: {
    type: Number,
    default: null
  }
})

const emit = defineEmits(['select', 'new-conversation'])

const loading = ref(false)
const conversations = ref([])
const searchQuery = ref('')

const filteredConversations = computed(() => {
  if (!searchQuery.value) return conversations.value
  
  return conversations.value.filter(conv =>
    conv.participant.name.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
    conv.last_message.toLowerCase().includes(searchQuery.value.toLowerCase())
  )
})

const loadConversations = async () => {
  loading.value = true
  try {
    const response = await messagesAPI.getConversations()
    conversations.value = response.data.results || response.data
  } catch (error) {
    console.error('Erreur chargement conversations:', error)
  } finally {
    loading.value = false
  }
}

const handleSearch = debounce(() => {
  // Search is handled by computed property
}, 300)

const getInitials = (name) => {
  return name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2)
}

const formatTime = (date) => {
  return formatRelativeTime(date)
}

function debounce(func, wait) {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

onMounted(() => {
  loadConversations()
})

// Expose loadConversations for parent component
defineExpose({
  loadConversations
})
</script>

<style scoped>
.message-list-container {
  display: flex;
  flex-direction: column;
  height: 100%;
  background: white;
  border-right: 1px solid #e0e0e0;
}

.message-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  border-bottom: 1px solid #e0e0e0;
}

.search-box {
  padding: 0 20px;
}

.conversations-list {
  flex-grow: 1;
  overflow-y: auto;
}

.empty-state {
  text-align: center;
  padding: 40px 20px;
  color: #999;
}

.conversation-item {
  display: flex;
  align-items: center;
  padding: 16px 20px;
  cursor: pointer;
  transition: background-color 0.2s;
  border-bottom: 1px solid #f5f5f5;
}

.conversation-item:hover {
  background-color: #f8f9fa;
}

.conversation-item.active {
  background-color: #e3f2fd;
  border-left: 3px solid #2196f3;
}

.conversation-item.unread {
  background-color: #f0f7ff;
}

.conversation-avatar {
  position: relative;
  margin-right: 12px;
  flex-shrink: 0;
}

.conversation-avatar img {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  object-fit: cover;
}

.avatar-placeholder {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  font-size: 1.1rem;
}

.online-indicator {
  position: absolute;
  bottom: 2px;
  right: 2px;
  width: 12px;
  height: 12px;
  background-color: #4caf50;
  border: 2px solid white;
  border-radius: 50%;
}

.conversation-content {
  flex-grow: 1;
  min-width: 0;
}

.conversation-header-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 4px;
}

.conversation-name {
  font-weight: 600;
  color: #333;
}

.conversation-time {
  font-size: 0.75rem;
  color: #999;
}

.conversation-preview {
  display: flex;
  align-items: center;
}

.me-indicator {
  color: #4caf50;
  margin-right: 4px;
  flex-shrink: 0;
}

.message-text {
  font-size: 0.85rem;
  color: #666;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.unread-badge {
  min-width: 24px;
  height: 24px;
  background-color: #2196f3;
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.75rem;
  font-weight: 600;
  margin-left: 8px;
  flex-shrink: 0;
}

@media (max-width: 768px) {
  .conversation-item {
    padding: 12px 16px;
  }

  .conversation-avatar img,
  .avatar-placeholder {
    width: 40px;
    height: 40px;
  }
}
</style>
```

### `src/components/messaging/MessageThread.vue`

```vue
<template>
  <div class="message-thread-container">
    <!-- Thread Header -->
    <div v-if="conversation" class="thread-header">
      <div class="participant-info">
        <img
          v-if="conversation.participant.avatar"
          :src="conversation.participant.avatar"
          :alt="conversation.participant.name"
          class="participant-avatar"
        >
        <div v-else class="avatar-placeholder">
          {{ getInitials(conversation.participant.name) }}
        </div>
        <div>
          <div class="participant-name">{{ conversation.participant.name }}</div>
          <div class="participant-status">
            <span class="status-dot" :class="{ online: conversation.participant.online }"></span>
            {{ conversation.participant.online ? 'En ligne' : 'Hors ligne' }}
          </div>
        </div>
      </div>
      <div class="thread-actions">
        <button class="btn btn-link" title="Informations">
          <i class="bi bi-info-circle"></i>
        </button>
        <button class="btn btn-link" @click="$emit('close')" title="Fermer">
          <i class="bi bi-x-lg"></i>
        </button>
      </div>
    </div>

    <!-- Messages -->
    <div v-if="conversation" class="messages-container" ref="messagesContainer">
      <div
        v-for="(message, index) in messages"
        :key="message.id"
        class="message-wrapper"
        :class="{ 'message-me': message.sender === 'me', 'message-other': message.sender !== 'me' }"
      >
        <div class="message-bubble">
          <div v-if="message.file" class="message-file">
            <i class="bi bi-file-earmark"></i>
            <a :href="message.file.url" target="_blank" class="file-link">
              {{ message.file.name }}
            </a>
          </div>
          <div class="message-text">{{ message.content }}</div>
          <div class="message-meta">
            <span class="message-time">{{ formatMessageTime(message.created_at) }}</span>
            <span v-if="message.sender === 'me'" class="message-status">
              <i class="bi" :class="message.read ? 'bi-check2-all' : 'bi-check2'"></i>
            </span>
          </div>
        </div>
      </div>

      <!-- Typing indicator -->
      <div v-if="isTyping" class="typing-indicator">
        <div class="typing-dots">
          <span></span>
          <span></span>
          <span></span>
        </div>
      </div>
    </div>

    <!-- Empty State -->
    <div v-else class="empty-thread">
      <i class="bi bi-chat-dots fs-1"></i>
      <p>Sélectionnez une conversation pour commencer</p>
    </div>

    <!-- Message Input -->
    <div v-if="conversation" class="message-input-container">
      <div v-if="selectedFile" class="selected-file">
        <span class="file-name">{{ selectedFile.name }}</span>
        <button class="btn btn-sm btn-link" @click="selectedFile = null">
          <i class="bi bi-x"></i>
        </button>
      </div>
      
      <form @submit.prevent="sendMessage" class="message-form">
        <button
          type="button"
          class="btn btn-link attach-btn"
          @click="triggerFileInput"
          title="Joindre un fichier"
        >
          <i class="bi bi-paperclip"></i>
        </button>
        <input
          ref="fileInput"
          type="file"
          class="d-none"
          @change="handleFileSelect"
        >
        
        <textarea
          v-model="newMessage"
          class="form-control message-input"
          placeholder="Écrivez votre message..."
          rows="1"
          @keydown.enter.prevent="handleEnter"
          ref="messageInput"
        ></textarea>
        
        <button
          type="submit"
          class="btn btn-primary send-btn"
          :disabled="!newMessage.trim() && !selectedFile"
        >
          <i class="bi bi-send"></i>
        </button>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref, watch, nextTick, onMounted } from 'vue'
import { messagesAPI } from '@/api/messages'
import { formatDateTime } from '@/utils/formatters'

const props = defineProps({
  conversationId: {
    type: Number,
    default: null
  }
})

const emit = defineEmits(['close'])

const conversation = ref(null)
const messages = ref([])
const newMessage = ref('')
const isTyping = ref(false)
const selectedFile = ref(null)
const fileInput = ref(null)
const messageInput = ref(null)
const messagesContainer = ref(null)

const loadConversation = async () => {
  if (!props.conversationId) return

  try {
    const [convResponse, messagesResponse] = await Promise.all([
      messagesAPI.getConversation(props.conversationId),
      messagesAPI.getMessages(props.conversationId)
    ])

    conversation.value = convResponse.data
    messages.value = messagesResponse.data.results || messagesResponse.data

    // Mark as read
    await messagesAPI.markAsRead(props.conversationId)

    // Scroll to bottom
    nextTick(() => {
      scrollToBottom()
    })
  } catch (error) {
    console.error('Erreur chargement conversation:', error)
  }
}

const sendMessage = async () => {
  if ((!newMessage.value.trim() && !selectedFile.value) || !props.conversationId) return

  try {
    let data = { content: newMessage.value }

    if (selectedFile.value) {
      // Upload file first
      const uploadResponse = await messagesAPI.uploadFile(props.conversationId, selectedFile.value)
      data.file_id = uploadResponse.data.id
    }

    const response = await messagesAPI.sendMessage(props.conversationId, data)
    messages.value.push(response.data)

    // Clear inputs
    newMessage.value = ''
    selectedFile.value = null

    // Scroll to bottom
    nextTick(() => {
      scrollToBottom()
    })

    // Focus input
    messageInput.value?.focus()
  } catch (error) {
    console.error('Erreur envoi message:', error)
  }
}

const handleEnter = (e) => {
  if (!e.shiftKey) {
    sendMessage()
  }
}

const triggerFileInput = () => {
  fileInput.value?.click()
}

const handleFileSelect = (e) => {
  const file = e.target.files[0]
  if (file) {
    selectedFile.value = file
  }
}

const scrollToBottom = () => {
  if (messagesContainer.value) {
    messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
  }
}

const getInitials = (name) => {
  return name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2)
}

const formatMessageTime = (date) => {
  return formatDateTime(date)
}

// Auto-resize textarea
watch(newMessage, () => {
  if (messageInput.value) {
    messageInput.value.style.height = 'auto'
    messageInput.value.style.height = messageInput.value.scrollHeight + 'px'
  }
})

// Watch conversation ID changes
watch(() => props.conversationId, () => {
  loadConversation()
}, { immediate: true })

onMounted(() => {
  // Setup WebSocket for real-time messages
  // This would connect to your WebSocket server
})
</script>

<style scoped>
.message-thread-container {
  display: flex;
  flex-direction: column;
  height: 100%;
  background: #f5f5f5;
}

.thread-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  background: white;
  border-bottom: 1px solid #e0e0e0;
}

.participant-info {
  display: flex;
  align-items: center;
  gap: 12px;
}

.participant-avatar {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  object-fit: cover;
}

.avatar-placeholder {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  font-size: 1.1rem;
}

.participant-name {
  font-weight: 600;
  color: #333;
}

.participant-status {
  font-size: 0.85rem;
  color: #666;
  display: flex;
  align-items: center;
  gap: 4px;
}

.status-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background-color: #999;
}

.status-dot.online {
  background-color: #4caf50;
}

.thread-actions {
  display: flex;
  gap: 8px;
}

.thread-actions .btn-link {
  color: #666;
  padding: 8px;
}

.messages-container {
  flex-grow: 1;
  overflow-y: auto;
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.message-wrapper {
  display: flex;
}

.message-wrapper.message-me {
  justify-content: flex-end;
}

.message-wrapper.message-other {
  justify-content: flex-start;
}

.message-bubble {
  max-width: 70%;
  padding: 12px 16px;
  border-radius: 18px;
  position: relative;
}

.message-me .message-bubble {
  background: #2196f3;
  color: white;
  border-bottom-right-radius: 4px;
}

.message-other .message-bubble {
  background: white;
  color: #333;
  border-bottom-left-radius: 4px;
  box-shadow: 0 1px 2px rgba(0,0,0,0.1);
}

.message-file {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px;
  background: rgba(255,255,255,0.1);
  border-radius: 8px;
  margin-bottom: 8px;
}

.file-link {
  color: inherit;
  text-decoration: underline;
  word-break: break-all;
}

.message-text {
  line-height: 1.5;
  white-space: pre-wrap;
  word-wrap: break-word;
}

.message-meta {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 4px;
  margin-top: 4px;
  font-size: 0.7rem;
  opacity: 0.8;
}

.message-status {
  color: #4caf50;
}

.typing-indicator {
  padding: 12px 20px;
}

.typing-dots {
  display: inline-flex;
  gap: 4px;
}

.typing-dots span {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #999;
  animation: typing 1.4s infinite;
}

.typing-dots span:nth-child(2) {
  animation-delay: 0.2s;
}

.typing-dots span:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes typing {
  0%, 60%, 100% {
    transform: translateY(0);
  }
  30% {
    transform: translateY(-4px);
  }
}

.empty-thread {
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: #999;
}

.message-input-container {
  background: white;
  border-top: 1px solid #e0e0e0;
  padding: 16px 20px;
}

.selected-file {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  background: #e3f2fd;
  border-radius: 8px;
  margin-bottom: 12px;
}

.file-name {
  font-size: 0.9rem;
  color: #1976d2;
}

.message-form {
  display: flex;
  align-items: flex-end;
  gap: 12px;
}

.attach-btn {
  color: #666;
  padding: 8px;
}

.message-input {
  flex-grow: 1;
  border: 1px solid #e0e0e0;
  border-radius: 24px;
  padding: 12px 16px;
  resize: none;
  max-height: 120px;
}

.message-input:focus {
  border-color: #2196f3;
  box-shadow: 0 0 0 2px rgba(33, 150, 243, 0.1);
}

.send-btn {
  border-radius: 50%;
  width: 48px;
  height: 48px;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
}

@media (max-width: 768px) {
  .thread-header {
    padding: 12px 16px;
  }

  .message-bubble {
    max-width: 85%;
  }

  .message-input-container {
    padding: 12px 16px;
  }
}
</style>
```

### `src/views/messaging/Messages.vue`

```vue
<template>
  <div class="messages-page">
    <div class="messages-layout">
      <!-- Conversations List -->
      <div class="conversations-panel">
        <MessageList
          :selected-conversation="selectedConversation"
          @select="selectConversation"
          @new-conversation="showNewConversationModal = true"
          ref="messageListRef"
        />
      </div>

      <!-- Message Thread -->
      <div class="thread-panel">
        <MessageThread
          :conversation-id="selectedConversation"
          @close="selectedConversation = null"
        />
      </div>
    </div>

    <!-- New Conversation Modal -->
    <div
      class="modal fade"
      id="newConversationModal"
      tabindex="-1"
      ref="newConversationModal"
    >
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Nouvelle conversation</h5>
            <button
              type="button"
              class="btn-close"
              data-bs-dismiss="modal"
            ></button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="createConversation">
              <div class="mb-3">
                <label class="form-label">Destinataire</label>
                <select
                  v-model="newConversationForm.recipient"
                  class="form-select"
                  required
                >
                  <option value="">Sélectionner un destinataire</option>
                  <option
                    v-for="user in availableUsers"
                    :key="user.id"
                    :value="user.id"
                  >
                    {{ user.name }} - {{ user.role }}
                  </option>
                </select>
              </div>
              <div class="mb-3">
                <label class="form-label">Message</label>
                <textarea
                  v-model="newConversationForm.message"
                  class="form-control"
                  rows="4"
                  required
                  placeholder="Votre message..."
                ></textarea>
              </div>
              <div class="d-flex justify-content-end gap-2">
                <button
                  type="button"
                  class="btn btn-secondary"
                  data-bs-dismiss="modal"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  class="btn btn-primary"
                  :disabled="submitting"
                >
                  {{ submitting ? 'Envoi...' : 'Envoyer' }}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue'
import { Modal } from 'bootstrap'
import MessageList from '@/components/messaging/MessageList.vue'
import MessageThread from '@/components/messaging/MessageThread.vue'
import { messagesAPI } from '@/api/messages'
import { useToast } from 'vue-toastification'

const toast = useToast()

const selectedConversation = ref(null)
const showNewConversationModal = ref(false)
const submitting = ref(false)
const availableUsers = ref([])
const newConversationForm = ref({
  recipient: '',
  message: ''
})
let newConversationModalInstance = null
const newConversationModal = ref(null)
const messageListRef = ref(null)

const loadAvailableUsers = async () => {
  try {
    const response = await fetch('/api/users/available-for-chat/', {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('access_token')}`
      }
    })
    const data = await response.json()
    availableUsers.value = data.results || data
  } catch (error) {
    console.error('Erreur chargement utilisateurs:', error)
  }
}

const selectConversation = (conversationId) => {
  selectedConversation.value = conversationId
}

const createConversation = async () => {
  submitting.value = true
  try {
    const response = await messagesAPI.createConversation({
      recipient_id: newConversationForm.value.recipient,
      message: newConversationForm.value.message
    })

    toast.success('Conversation créée avec succès')
    
    // Select the new conversation
    selectedConversation.value = response.data.id
    
    // Refresh the list
    messageListRef.value?.loadConversations()
    
    // Close modal
    if (newConversationModalInstance) {
      newConversationModalInstance.hide()
    }

    // Reset form
    newConversationForm.value = {
      recipient: '',
      message: ''
    }
  } catch (error) {
    toast.error('Erreur lors de la création de la conversation')
  } finally {
    submitting.value = false
  }
}

const openModal = () => {
  if (!newConversationModalInstance) {
    newConversationModalInstance = new Modal(newConversationModal.value)
  }
  newConversationModalInstance.show()
}

onMounted(() => {
  loadAvailableUsers()

  nextTick(() => {
    const modalElement = document.getElementById('newConversationModal')
    if (modalElement) {
      newConversationModalInstance = new Modal(modalElement)
    }
  })
})
</script>

<style scoped>
.messages-page {
  height: calc(100vh - 56px);
}

.messages-layout {
  display: flex;
  height: 100%;
}

.conversations-panel {
  width: 380px;
  flex-shrink: 0;
  border-right: 1px solid #e0e0e0;
}

.thread-panel {
  flex-grow: 1;
  min-width: 0;
}

@media (max-width: 768px) {
  .conversations-panel {
    width: 100%;
    display: flex;
  }

  .thread-panel {
    display: none;
  }

  .thread-panel.active {
    display: block;
    position: fixed;
    top: 56px;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 1000;
  }
}
</style>
```

---

## 4. Export PDF/Excel

### Installation

```bash
# PDF generation
npm install jspdf jspdf-autotable

# Excel generation
npm install xlsx

# File saver
npm install file-saver
```

### `src/utils/exportPDF.js`

```javascript
import jsPDF from 'jspdf'
import 'jspdf-autotable'
import { formatCurrency, formatDate } from './formatters'
import dayjs from 'dayjs'

/**
 * Export financial report to PDF
 */
export const exportFinancialReportPDF = (data, fileName = 'rapport_financier.pdf') => {
  const doc = new jsPDF()
  
  // Title
  doc.setFontSize(20)
  doc.setFont('helvetica', 'bold')
  doc.text('Rapport Financier', 14, 20)
  
  // Subtitle
  doc.setFontSize(12)
  doc.setFont('helvetica', 'normal')
  doc.text(`Résidence: ${data.residence}`, 14, 30)
  doc.text(`Année: ${data.annee}`, 14, 38)
  doc.text(`Généré le: ${formatDate(new Date())}`, 14, 46)
  
  // Summary section
  doc.setFontSize(14)
  doc.setFont('helvetica', 'bold')
  doc.text('Résumé', 14, 60)
  
  const summaryData = [
    ['Recettes Totales', formatCurrency(data.total_recettes)],
    ['Dépenses Totales', formatCurrency(data.total_depenses)],
    ['Solde', formatCurrency(data.solde)],
    ['Taux de recouvrement', `${data.taux_recouvrement}%`],
  ]
  
  doc.autoTable({
    startY: 65,
    head: [['Libellé', 'Montant']],
    body: summaryData,
    theme: 'striped',
    headStyles: { fillColor: [66, 139, 202] },
  })
  
  // Expenses by category
  if (data.depenses_par_categorie && data.depenses_par_categorie.length > 0) {
    doc.setFontSize(14)
    doc.setFont('helvetica', 'bold')
    doc.text('Dépenses par Catégorie', 14, doc.lastAutoTable.finalY + 15)
    
    const categoryData = data.depenses_par_categorie.map(cat => [
      cat.categorie,
      formatCurrency(cat.montant),
      `${cat.percentage}%`
    ])
    
    doc.autoTable({
      startY: doc.lastAutoTable.finalY + 20,
      head: [['Catégorie', 'Montant', '% du total']],
      body: categoryData,
      theme: 'striped',
      headStyles: { fillColor: [220, 53, 69] },
    })
  }
  
  // Monthly evolution
  if (data.evolution_mensuelle && data.evolution_mensuelle.length > 0) {
    doc.addPage()
    
    doc.setFontSize(14)
    doc.setFont('helvetica', 'bold')
    doc.text('Évolution Mensuelle', 14, 20)
    
    const monthlyData = data.evolution_mensuelle.map(mois => [
      mois.mois,
      formatCurrency(mois.recettes),
      formatCurrency(mois.depenses),
      formatCurrency(mois.solde)
    ])
    
    doc.autoTable({
      startY: 25,
      head: [['Mois', 'Recettes', 'Dépenses', 'Solde']],
      body: monthlyData,
      theme: 'striped',
      headStyles: { fillColor: [40, 167, 69] },
    })
  }
  
  // Save
  doc.save(fileName)
}

/**
 * Export copropriétaires list to PDF
 */
export const exportCoproprietairesPDF = (data, residence, fileName = 'coproprietaires.pdf') => {
  const doc = new jsPDF()
  
  // Title
  doc.setFontSize(20)
  doc.setFont('helvetica', 'bold')
  doc.text('Liste des Copropriétaires', 14, 20)
  
  // Subtitle
  doc.setFontSize(12)
  doc.setFont('helvetica', 'normal')
  doc.text(`Résidence: ${residence}`, 14, 30)
  doc.text(`Généré le: ${formatDate(new Date())}`, 14, 38)
  
  // Table data
  const tableData = data.map(copro => [
    `${copro.nom} ${copro.prenom}`,
    copro.appartement,
    `${copro.quote_part}%`,
    copro.email || '-',
    copro.telephone || '-',
    copro.statut
  ])
  
  // Generate table
  doc.autoTable({
    startY: 45,
    head: [['Nom', 'Appartement', 'Quote-part', 'Email', 'Téléphone', 'Statut']],
    body: tableData,
    theme: 'striped',
    headStyles: { fillColor: [102, 126, 234] },
    styles: { fontSize: 9 },
    columnStyles: {
      0: { cellWidth: 40 },
      1: { cellWidth: 25 },
      2: { cellWidth: 20 },
      3: { cellWidth: 45 },
      4: { cellWidth: 30 },
      5: { cellWidth: 20 }
    }
  })
  
  // Save
  doc.save(fileName)
}

/**
 * Export AG report to PDF
 */
export const exportAGReportPDF = (data, fileName = 'rapport_ag.pdf') => {
  const doc = new jsPDF()
  
  // Title
  doc.setFontSize(20)
  doc.setFont('helvetica', 'bold')
  doc.text('Rapport d\'Assemblée Générale', 14, 20)
  
  // AG Info
  doc.setFontSize(12)
  doc.setFont('helvetica', 'normal')
  doc.text(`Résidence: ${data.residence}`, 14, 30)
  doc.text(`Date: ${formatDate(data.date)}`, 14, 38)
  doc.text(`Type: ${data.type}`, 14, 46)
  
  // Quorum
  doc.setFontSize(14)
  doc.setFont('helvetica', 'bold')
  doc.text('Quorum', 14, 60)
  
  const quorumData = [
    ['Copropriétaires présents', `${data.quorum.presentes}/${data.quorum.total}`],
    ['Quote-part présente', `${data.quorum.quote_part_presente}%`],
    ['Quorum atteint', data.quorum.atteint ? 'Oui' : 'Non'],
  ]
  
  doc.autoTable({
    startY: 65,
    head: [['Information', 'Valeur']],
    body: quorumData,
    theme: 'striped',
    headStyles: { fillColor: [102, 126, 234] },
  })
  
  // Votes
  if (data.votes && data.votes.length > 0) {
    doc.setFontSize(14)
    doc.setFont('helvetica', 'bold')
    doc.text('Résultats des Votes', 14, doc.lastAutoTable.finalY + 15)
    
    const votesData = data.votes.map(vote => [
      vote.sujet,
      `${vote.pour}% Pour`,
      `${vote.contre}% Contre`,
      `${vote.abstention}% Abstention`,
      vote.resultat
    ])
    
    doc.autoTable({
      startY: doc.lastAutoTable.finalY + 20,
      head: [['Sujet', 'Pour', 'Contre', 'Abstention', 'Résultat']],
      body: votesData,
      theme: 'striped',
      headStyles: { fillColor: [232, 62, 140] },
    })
  }
  
  // Decisions
  if (data.decisions && data.decisions.length > 0) {
    doc.addPage()
    
    doc.setFontSize(14)
    doc.setFont('helvetica', 'bold')
    doc.text('Décisions Prises', 14, 20)
    
    const decisionsData = data.decisions.map(dec => [
      dec.sujet,
      dec.description,
      dec.responsable,
      formatDate(dec.echeance)
    ])
    
    doc.autoTable({
      startY: 25,
      head: [['Sujet', 'Description', 'Responsable', 'Échéance']],
      body: decisionsData,
      theme: 'striped',
      headStyles: { fillColor: [40, 167, 69] },
      styles: { fontSize: 9 },
    })
  }
  
  // Save
  doc.save(fileName)
}
```

### `src/utils/exportExcel.js`

```javascript
import * as XLSX from 'xlsx'
import { formatCurrency, formatDate } from './formatters'
import { saveAs } from 'file-saver'

/**
 * Export data to Excel
 */
export const exportToExcel = (data, fileName = 'export.xlsx', sheetName = 'Données') => {
  // Create workbook
  const wb = XLSX.utils.book_new()
  
  // Convert data to worksheet
  const ws = XLSX.utils.json_to_sheet(data)
  
  // Set column widths
  const colWidths = Object.keys(data[0] || {}).map(() => ({ wch: 20 }))
  ws['!cols'] = colWidths
  
  // Add worksheet to workbook
  XLSX.utils.book_append_sheet(wb, ws, sheetName)
  
  // Write file
  XLSX.writeFile(wb, fileName)
}

/**
 * Export financial report to Excel
 */
export const exportFinancialReportExcel = (data, fileName = 'rapport_financier.xlsx') => {
  const wb = XLSX.utils.book_new()
  
  // Summary sheet
  const summaryData = [
    { 'Libellé': 'Recettes Totales', 'Montant': data.total_recettes },
    { 'Libellé': 'Dépenses Totales', 'Montant': data.total_depenses },
    { 'Libellé': 'Solde', 'Montant': data.solde },
    { 'Libellé': 'Taux de recouvrement', 'Montant': `${data.taux_recouvrement}%` },
  ]
  
  const summaryWs = XLSX.utils.json_to_sheet(summaryData)
  XLSX.utils.book_append_sheet(wb, summaryWs, 'Résumé')
  
  // Expenses by category sheet
  if (data.depenses_par_categorie && data.depenses_par_categorie.length > 0) {
    const categoryWs = XLSX.utils.json_to_sheet(data.depenses_par_categorie)
    XLSX.utils.book_append_sheet(wb, categoryWs, 'Dépenses par catégorie')
  }
  
  // Monthly evolution sheet
  if (data.evolution_mensuelle && data.evolution_mensuelle.length > 0) {
    const monthlyWs = XLSX.utils.json_to_sheet(data.evolution_mensuelle)
    XLSX.utils.book_append_sheet(wb, monthlyWs, 'Évolution mensuelle')
  }
  
  // Write file
  XLSX.writeFile(wb, fileName)
}

/**
 * Export copropriétaires to Excel
 */
export const exportCoproprietairesExcel = (data, residence, fileName = 'coproprietaires.xlsx') => {
  const wb = XLSX.utils.book_new()
  
  // Format data for Excel
  const formattedData = data.map(copro => ({
    'Nom': `${copro.nom} ${copro.prenom}`,
    'Appartement': copro.appartement,
    'Étage': copro.etage || '-',
    'Quote-part (%)': copro.quote_part,
    'Email': copro.email || '-',
    'Téléphone': copro.telephone || '-',
    'Adresse': copro.adresse || '-',
    'Statut': copro.statut,
    'Date entrée': copro.date_entree ? formatDate(copro.date_entree) : '-',
  }))
  
  const ws = XLSX.utils.json_to_sheet(formattedData)
  ws['!cols'] = [
    { wch: 25 },
    { wch: 15 },
    { wch: 10 },
    { wch: 15 },
    { wch: 30 },
    { wch: 15 },
    { wch: 35 },
    { wch: 15 },
    { wch: 15 },
  ]
  
  XLSX.utils.book_append_sheet(wb, ws, 'Copropriétaires')
  
  // Add summary sheet
  const summaryData = [
    { 'Statistique': 'Total copropriétaires', 'Valeur': data.length },
    { 'Statistique': 'Copropriétaires actifs', 'Valeur': data.filter(c => c.statut === 'actif').length },
    { 'Statistique': 'Copropriétaires inactifs', 'Valeur': data.filter(c => c.statut === 'inactif').length },
  ]
  
  const summaryWs = XLSX.utils.json_to_sheet(summaryData)
  XLSX.utils.book_append_sheet(wb, summaryWs, 'Résumé')
  
  XLSX.writeFile(wb, fileName)
}

/**
 * Export paiements to Excel
 */
export const exportPaiementsExcel = (data, fileName = 'paiements.xlsx') => {
  const wb = XLSX.utils.book_new()
  
  const formattedData = data.map(paiement => ({
    'Date': formatDate(paiement.date_paiement),
    'Copropriétaire': paiement.coproprietaire_nom,
    'Appartement': paiement.appartement,
    'Montant': paiement.montant,
    'Mode': paiement.mode_paiement,
    'Référence': paiement.reference_banque || '-',
    'Appel de fonds': paiement.appel_fonds_numero,
  }))
  
  const ws = XLSX.utils.json_to_sheet(formattedData)
  ws['!cols'] = [
    { wch: 15 },
    { wch: 25 },
    { wch: 15 },
    { wch: 15 },
    { wch: 15 },
    { wch: 20 },
    { wch: 20 },
  ]
  
  XLSX.utils.book_append_sheet(wb, ws, 'Paiements')
  XLSX.writeFile(wb, fileName)
}

/**
 * Export budget to Excel
 */
export const exportBudgetExcel = (data, fileName = 'budget.xlsx') => {
  const wb = XLSX.utils.book_new()
  
  // Budget lines
  const budgetLines = data.lignes.map(ligne => ({
    'Catégorie': ligne.categorie,
    'Budget prévisionnel': ligne.montant_previsionnel,
    'Réalisé': ligne.montant_realise,
    'Écart': ligne.montant_realise - ligne.montant_previsionnel,
    '% Exécution': ((ligne.montant_realise / ligne.montant_previsionnel) * 100).toFixed(2) + '%',
  }))
  
  const ws = XLSX.utils.json_to_sheet(budgetLines)
  ws['!cols'] = [
    { wch: 25 },
    { wch: 20 },
    { wch: 15 },
    { wch: 15 },
    { wch: 15 },
  ]
  
  XLSX.utils.book_append_sheet(wb, ws, 'Budget')
  
  // Summary
  const summaryData = [
    { 'Poste': 'Budget total prévu', 'Montant': data.budget_total },
    { 'Poste': 'Dépenses réalisées', 'Montant': data.depenses_realisees },
    { 'Poste': 'Solde restant', 'Montant': data.solde_restant },
  ]
  
  const summaryWs = XLSX.utils.json_to_sheet(summaryData)
  XLSX.utils.book_append_sheet(wb, summaryWs, 'Résumé')
  
  XLSX.writeFile(wb, fileName)
}
```

### `src/components/common/ExportButton.vue`

```vue
<template>
  <div class="export-dropdown">
    <div class="btn-group">
      <button
        class="btn btn-outline-primary"
        @click="handleExport('pdf')"
        :disabled="loading"
      >
        <i class="bi bi-file-earmark-pdf me-1"></i>
        PDF
      </button>
      <button
        class="btn btn-outline-success"
        @click="handleExport('excel')"
        :disabled="loading"
      >
        <i class="bi bi-file-earmark-excel me-1"></i>
        Excel
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useToast } from 'vue-toastification'

const props = defineProps({
  type: {
    type: String,
    required: true,
    validator: (value) => ['financial', 'coproprietaires', 'paiements', 'budget', 'ag'].includes(value)
  },
  data: {
    type: Object,
    required: true
  },
  fileName: {
    type: String,
    default: ''
  }
})

const toast = useToast()
const loading = ref(false)

const handleExport = async (format) => {
  loading.value = true
  
  try {
    const fileName = props.fileName || `${props.type}_export.${format}`
    
    switch (props.type) {
      case 'financial':
        if (format === 'pdf') {
          const { exportFinancialReportPDF } = await import('@/utils/exportPDF')
          exportFinancialReportPDF(props.data, fileName)
        } else {
          const { exportFinancialReportExcel } = await import('@/utils/exportExcel')
          exportFinancialReportExcel(props.data, fileName)
        }
        break
        
      case 'coproprietaires':
        if (format === 'pdf') {
          const { exportCoproprietairesPDF } = await import('@/utils/exportPDF')
          exportCoproprietairesPDF(props.data, props.data.residence, fileName)
        } else {
          const { exportCoproprietairesExcel } = await import('@/utils/exportExcel')
          exportCoproprietairesExcel(props.data, props.data.residence, fileName)
        }
        break
        
      case 'paiements':
        const { exportPaiementsExcel } = await import('@/utils/exportExcel')
        exportPaiementsExcel(props.data, fileName)
        break
        
      case 'budget':
        const { exportBudgetExcel } = await import('@/utils/exportExcel')
        exportBudgetExcel(props.data, fileName)
        break
        
      case 'ag':
        const { exportAGReportPDF } = await import('@/utils/exportPDF')
        exportAGReportPDF(props.data, fileName)
        break
    }
    
    toast.success(`Export ${format.toUpperCase()} réussi`)
  } catch (error) {
    console.error('Export error:', error)
    toast.error('Erreur lors de l\'export')
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.export-dropdown {
  display: inline-block;
}

.btn-group .btn {
  min-width: 100px;
}
</style>
```

### Usage Example

```vue
<template>
  <div class="report-page">
    <div class="page-header">
      <h2>Rapport Financier</h2>
      <ExportButton
        type="financial"
        :data="reportData"
        file-name="rapport_financier_2025"
      />
    </div>
    
    <!-- Report content here -->
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import ExportButton from '@/components/common/ExportButton.vue'

const reportData = ref({})

onMounted(async () => {
  // Load report data
  const response = await fetch('/api/residences/1/rapports/financier/2025/')
  reportData.value = await response.json()
})
</script>
```

---

## Installation des nouvelles dépendances

Ajoutez ces packages à votre `package.json` :

```json
{
  "dependencies": {
    "chart.js": "^4.4.0",
    "vue-chartjs": "^5.3.0",
    "apexcharts": "^3.44.0",
    "vue3-apexcharts": "^1.4.1",
    "socket.io-client": "^4.6.0",
    "@vueuse/core": "^10.7.0",
    "jspdf": "^2.5.1",
    "jspdf-autotable": "^3.8.1",
    "xlsx": "^0.18.5",
    "file-saver": "^2.0.5"
  }
}
```

Puis installez-les :

```bash
npm install
```

---

## Résumé

Ce document ajoute les fonctionnalités suivantes à votre application :

1. **Graphiques financiers** avec Chart.js et ApexCharts
2. **Système de notifications en temps réel** avec WebSocket
3. **Module de messagerie complet** avec conversations et fichiers
4. **Export PDF et Excel** pour tous les rapports

Ces composants sont prêts à être intégrés dans votre application Vue.js existante !
