# Guide Complet Frontend Vue.js - Application Syndic Multi-Résidences

## 📋 Table des matières

1. [Architecture du projet](#architecture-du-projet)
2. [Installation et configuration](#installation-et-configuration)
3. [Structure du projet](#structure-du-projet)
4. [Configuration Axios](#configuration-axios)
5. [Composants Core](#composants-core)
6. [Modules de l'application](#modules-de-lapplication)
7. [Déploiement](#déploiement)

---

## Architecture du projet

### Stack Technique
- **Vue.js 3** (Composition API avec `<script setup>`)
- **Vue Router 4** (Navigation)
- **Pinia** (Gestion d'état)
- **Axios** (Requêtes HTTP)
- **Bootstrap 5** (Styling)
- **Bootstrap Icons** (Icônes)

### Caractéristiques
- Application SPA (Single Page Application)
- Responsive design (mobile-first)
- Authentification JWT
- Gestion des erreurs
- Loading states
- Toasts/Notifications

---

## Installation et configuration

### 1. Création du projet

```bash
# Installer Vue CLI si non installé
npm install -g @vue/cli

# Créer le projet
vue create syndic-frontend
cd syndic-frontend
```

Choisir les options suivantes :
- Vue 3
- Vue Router
- Pinia (State Management)

### 2. Installer les dépendances

```bash
# Bootstrap 5
npm install bootstrap @popperjs/core

# Bootstrap Icons
npm install bootstrap-icons

# Axios
npm install axios

# Outils supplémentaires
npm install vue-toastification
npm install sweetalert2
npm install @vueuse/core
npm install dayjs
```

### 3. Configuration principale

#### `src/main.js`

```javascript
import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import router from './router'

// Bootstrap CSS & JS
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.bundle.min.js'
import 'bootstrap-icons/font/bootstrap-icons.css'

// Toast notifications
import Toast from 'vue-toastification'
import 'vue-toastification/dist/index.css'

const app = createApp(App)
const pinia = createPinia()

app.use(pinia)
app.use(router)
app.use(Toast, {
  timeout: 3000,
  position: 'top-right',
  closeOnClick: true,
  pauseOnHover: true,
})

app.mount('#app')
```

#### `vite.config.js` (si utilisant Vite)

```javascript
import { fileURLToPath, URL } from 'node:url'
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    }
  },
  server: {
    port: 8080,
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true
      }
    }
  }
})
```

---

## Structure du projet

```
syndic-frontend/
├── public/
│   └── favicon.ico
├── src/
│   ├── api/
│   │   ├── axios.js              # Configuration Axios
│   │   ├── auth.js               # API Authentification
│   │   ├── residences.js         # API Résidences
│   │   ├── coproprietaires.js    # API Copropriétaires
│   │   ├── finances.js           # API Finances
│   │   ├── prestataires.js       # API Prestataires
│   │   ├── assembles.js          # API Assemblées
│   │   ├── documents.js          # API Documents
│   │   └── rapports.js           # API Rapports
│   ├── assets/
│   │   └── styles/
│   │       └── custom.css        # Styles personnalisés
│   ├── components/
│   │   ├── common/
│   │   │   ├── Navbar.vue        # Barre de navigation
│   │   │   ├── Sidebar.vue       # Sidebar
│   │   │   ├── Footer.vue        # Footer
│   │   │   ├── LoadingSpinner.vue
│   │   │   └── ErrorAlert.vue
│   │   ├── coproprietaires/
│   │   │   ├── CoproprietaireList.vue
│   │   │   ├── CoproprietaireCard.vue
│   │   │   ├── CoproprietaireForm.vue
│   │   │   └── PaiementsHistory.vue
│   │   ├── finances/
│   │   │   ├── BudgetCard.vue
│   │   │   ├── DepenseList.vue
│   │   │   ├── RecetteList.vue
│   │   │   ├── AppelFondsForm.vue
│   │   │   └── FinanceChart.vue
│   │   ├── prestataires/
│   │   │   ├── PrestataireList.vue
│   │   │   ├── PrestataireCard.vue
│   │   │   ├── PrestataireForm.vue
│   │   │   └── FactureList.vue
│   │   ├── assembles/
│   │   │   ├── AGList.vue
│   │   │   ├── AGCard.vue
│   │   │   ├── AGForm.vue
│   │   │   └── VoteForm.vue
│   │   ├── documents/
│   │   │   ├── DocumentList.vue
│   │   │   ├── DocumentCard.vue
│   │   │   └── UploadDocument.vue
│   │   └── dashboard/
│   │       ├── StatCard.vue
│   │       ├── AlertCard.vue
│   │       └── RecentActivity.vue
│   ├── composables/
│   │   ├── useAuth.js            # Authentification
│   │   ├── useApi.js             # API helper
│   │   └── useToast.js           # Toasts
│   ├── layouts/
│   │   ├── DefaultLayout.vue
│   │   ├── AuthLayout.vue
│   │   └── DashboardLayout.vue
│   ├── router/
│   │   └── index.js              # Configuration Router
│   ├── stores/
│   │   ├── auth.js               # Store Authentification
│   │   ├── residences.js         # Store Résidences
│   │   └── user.js               # Store User
│   ├── utils/
│   │   ├── constants.js
│   │   ├── formatters.js
│   │   └── validators.js
│   ├── views/
│   │   ├── auth/
│   │   │   ├── Login.vue
│   │   │   └── Register.vue
│   │   ├── dashboard/
│   │   │   ├── Dashboard.vue
│   │   │   └── DashboardSyndic.vue
│   │   ├── residences/
│   │   │   ├── ResidenceList.vue
│   │   │   └── ResidenceDetail.vue
│   │   ├── coproprietaires/
│   │   │   ├── CoproprietaireList.vue
│   │   │   └── CoproprietaireDetail.vue
│   │   ├── finances/
│   │   │   ├── Finances.vue
│   │   │   ├── Budget.vue
│   │   │   ├── AppelsFonds.vue
│   │   │   └── Comptabilite.vue
│   │   ├── prestataires/
│   │   │   ├── PrestataireList.vue
│   │   │   └── PrestataireDetail.vue
│   │   ├── assembles/
│   │   │   ├── AssembleeList.vue
│   │   │   └── AssembleeDetail.vue
│   │   ├── documents/
│   │   │   ├── DocumentLibrary.vue
│   │   │   └── DocumentUpload.vue
│   │   ├── rapports/
│   │   │   ├── Rapports.vue
│   │   │   └── RapportFinance.vue
│   │   └── Profile.vue
│   ├── App.vue
│   └── main.js
├── .env
├── .env.example
├── .gitignore
├── index.html
├── package.json
└── vite.config.js
```

---

## Configuration Axios

### `src/api/axios.js`

```javascript
import axios from 'axios'
import { useAuthStore } from '@/stores/auth'
import { useToast } from 'vue-toastification'

const toast = useToast()

// Instance Axios de base
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8000/api',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Interceptor Request
api.interceptors.request.use(
  (config) => {
    const authStore = useAuthStore()
    if (authStore.token) {
      config.headers.Authorization = `Bearer ${authStore.token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Interceptor Response
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const authStore = useAuthStore()

    if (error.response?.status === 401) {
      // Token expiré ou invalide
      authStore.logout()
      window.location.href = '/login'
      toast.error('Session expirée. Veuillez vous reconnecter.')
    } else if (error.response?.status === 403) {
      toast.error('Accès non autorisé.')
    } else if (error.response?.status === 404) {
      toast.error('Ressource non trouvée.')
    } else if (error.response?.status >= 500) {
      toast.error('Erreur serveur. Veuillez réessayer.')
    }

    return Promise.reject(error)
  }
)

export default api
```

### `src/api/auth.js`

```javascript
import api from './axios'

export const authAPI = {
  // Login
  login(credentials) {
    return api.post('/auth/login/', credentials)
  },

  // Logout
  logout() {
    return api.post('/auth/logout/')
  },

  // Register
  register(userData) {
    return api.post('/auth/register/', userData)
  },

  // Refresh token
  refreshToken(refreshToken) {
    return api.post('/auth/token/refresh/', { refresh: refreshToken })
  },

  // Get current user
  getCurrentUser() {
    return api.get('/auth/me/')
  },

  // Change password
  changePassword(passwords) {
    return api.post('/auth/change-password/', passwords)
  },

  // Reset password request
  forgotPassword(email) {
    return api.post('/auth/forgot-password/', { email })
  },

  // Reset password confirm
  resetPassword(data) {
    return api.post('/auth/reset-password/', data)
  },
}
```

### `src/api/residences.js`

```javascript
import api from './axios'

export const residencesAPI = {
  // Liste des résidences
  getList(params = {}) {
    return api.get('/residences/', { params })
  },

  // Détail résidence
  getDetail(id) {
    return api.get(`/residences/${id}/`)
  },

  // Créer résidence
  create(data) {
    return api.post('/residences/', data)
  },

  // Mettre à jour
  update(id, data) {
    return api.put(`/residences/${id}/`, data)
  },

  // Supprimer
  delete(id) {
    return api.delete(`/residences/${id}/`)
  },

  // Statistiques résidence
  getStats(id) {
    return api.get(`/residences/${id}/stats/`)
  },

  // Copropriétaires d'une résidence
  getCoproprietaires(id, params = {}) {
    return api.get(`/residences/${id}/coproprietaires/`, { params })
  },
}
```

### `src/api/coproprietaires.js`

```javascript
import api from './axios'

export const coproprietairesAPI = {
  // Liste des copropriétaires
  getList(params = {}) {
    return api.get('/coproprietaires/', { params })
  },

  // Détail copropriétaire
  getDetail(id) {
    return api.get(`/coproprietaires/${id}/`)
  },

  // Créer copropriétaire
  create(data) {
    return api.post('/coproprietaires/', data)
  },

  // Mettre à jour
  update(id, data) {
    return api.put(`/coproprietaires/${id}/`, data)
  },

  // Supprimer
  delete(id) {
    return api.delete(`/coproprietaires/${id}/`)
  },

  // Historique des paiements
  getPaiements(id, params = {}) {
    return api.get(`/coproprietaires/${id}/paiements/`, { params })
  },

  // Documents personnels
  getDocuments(id) {
    return api.get(`/coproprietaires/${id}/documents/`)
  },

  // Demandes d'intervention
  getDemandes(id) {
    return api.get(`/coproprietaires/${id}/demandes/`)
  },

  // Créer demande
  createDemande(id, data) {
    return api.post(`/coproprietaires/${id}/demandes/`, data)
  },

  // Statistiques copropriétaire
  getStats(id) {
    return api.get(`/coproprietaires/${id}/stats/`)
  },
}
```

### `src/api/finances.js`

```javascript
import api from './axios'

export const financesAPI = {
  // Budgets
  getBudgets(residenceId, params = {}) {
    return api.get(`/residences/${residenceId}/budgets/`, { params })
  },

  createBudget(residenceId, data) {
    return api.post(`/residences/${residenceId}/budgets/`, data)
  },

  updateBudget(id, data) {
    return api.put(`/budgets/${id}/`, data)
  },

  // Appels de fonds
  getAppelsFonds(residenceId, params = {}) {
    return api.get(`/residences/${residenceId}/appels-fonds/`, { params })
  },

  createAppelFonds(residenceId, data) {
    return api.post(`/residences/${residenceId}/appels-fonds/`, data)
  },

  getAppelFondsDetail(id) {
    return api.get(`/appels-fonds/${id}/`)
  },

  // Cotisations
  getCotisations(appelFondsId, params = {}) {
    return api.get(`/appels-fonds/${appelFondsId}/cotisations/`, { params })
  },

  updateCotisation(id, data) {
    return api.put(`/cotisations/${id}/`, data)
  },

  // Paiements
  createPaiement(cotisationId, data) {
    return api.post(`/cotisations/${cotisationId}/paiements/`, data)
  },

  // Dépenses (Factures prestataires)
  getDepenses(residenceId, params = {}) {
    return api.get(`/residences/${residenceId}/depenses/`, { params })
  },

  createDepense(residenceId, data) {
    return api.post(`/residences/${residenceId}/depenses/`, data)
  },

  updateDepense(id, data) {
    return api.put(`/depenses/${id}/`, data)
  },

  // Recettes
  getRecettes(residenceId, params = {}) {
    return api.get(`/residences/${residenceId}/recettes/`, { params })
  },

  // Comptabilité
  getGrandLivre(residenceId, params = {}) {
    return api.get(`/residences/${residenceId}/comptabilite/grand-livre/`, { params })
  },

  getBilan(residenceId, annee) {
    return api.get(`/residences/${residenceId}/comptabilite/bilan/${annee}/`)
  },

  // Statistiques financières
  getStats(residenceId, annee) {
    return api.get(`/residences/${residenceId}/finances/stats/${annee}/`)
  },
}
```

### `src/api/prestataires.js`

```javascript
import api from './axios'

export const prestatairesAPI = {
  // Liste des prestataires
  getList(params = {}) {
    return api.get('/prestataires/', { params })
  },

  // Détail prestataire
  getDetail(id) {
    return api.get(`/prestataires/${id}/`)
  },

  // Créer prestataire
  create(data) {
    return api.post('/prestataires/', data, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
  },

  // Mettre à jour
  update(id, data) {
    return api.put(`/prestataires/${id}/`, data, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
  },

  // Supprimer
  delete(id) {
    return api.delete(`/prestataires/${id}/`)
  },

  // Factures d'un prestataire
  getFactures(id, params = {}) {
    return api.get(`/prestataires/${id}/factures/`, { params })
  },

  // Créer facture
  createFacture(id, data) {
    return api.post(`/prestataires/${id}/factures/`, data, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
  },

  // Contrats
  getContrats(id) {
    return api.get(`/prestataires/${id}/contrats/`)
  },

  // Devis
  getDevis(id) {
    return api.get(`/prestataires/${id}/devis/`)
  },
}
```

### `src/api/assembles.js`

```javascript
import api from './axios'

export const assemblesAPI = {
  // Liste des assemblées
  getList(params = {}) {
    return api.get('/assembles/', { params })
  },

  // Détail assemblée
  getDetail(id) {
    return api.get(`/assembles/${id}/`)
  },

  // Créer assemblée
  create(data) {
    return api.post('/assembles/', data)
  },

  // Mettre à jour
  update(id, data) {
    return api.put(`/assembles/${id}/`, data)
  },

  // Supprimer
  delete(id) {
    return api.delete(`/assembles/${id}/`)
  },

  // Générer convocation PDF
  generateConvocation(id) {
    return api.get(`/assembles/${id}/convocation/`, {
      responseType: 'blob',
    })
  },

  // Participants
  getParticipants(id) {
    return api.get(`/assembles/${id}/participants/`)
  },

  // Votes
  getVotes(id) {
    return api.get(`/assembles/${id}/votes/`)
  },

  // Enregistrer vote
  createVote(assembleeId, data) {
    return api.post(`/assembles/${assembleeId}/votes/`, data)
  },

  // Procès-verbal
  getPV(id) {
    return api.get(`/assembles/${id}/pv/`)
  },

  savePV(id, content) {
    return api.put(`/assembles/${id}/pv/`, { contenu: content })
  },

  // Export PV
  exportPV(id, format = 'pdf') {
    return api.get(`/assembles/${id}/pv/export/?format=${format}`, {
      responseType: 'blob',
    })
  },
}
```

### `src/api/documents.js`

```javascript
import api from './axios'

export const documentsAPI = {
  // Liste des documents
  getList(params = {}) {
    return api.get('/documents/', { params })
  },

  // Détail document
  getDetail(id) {
    return api.get(`/documents/${id}/`)
  },

  // Uploader document
  upload(data) {
    return api.post('/documents/upload/', data, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
  },

  // Mettre à jour document
  update(id, data) {
    return api.put(`/documents/${id}/`, data)
  },

  // Supprimer
  delete(id) {
    return api.delete(`/documents/${id}/`)
  },

  // Télécharger
  download(id) {
    return api.get(`/documents/${id}/download/`, {
      responseType: 'blob',
    })
  },

  // Documents par catégorie
  getByCategory(category, params = {}) {
    return api.get(`/documents/category/${category}/`, { params })
  },

  // Recherche
  search(query, params = {}) {
    return api.get('/documents/search/', {
      params: { q: query, ...params },
    })
  },
}
```

### `src/api/rapports.js`

```javascript
import api from './axios'

export const rapportsAPI = {
  // Rapport financier annuel
  getRapportFinancier(residenceId, annee) {
    return api.get(`/residences/${residenceId}/rapports/financier/${annee}/`)
  },

  // Rapport budget vs réel
  getBudgetVsReel(residenceId, annee) {
    return api.get(`/residences/${residenceId}/rapports/budget-reel/${annee}/`)
  },

  // Rapport impayés
  getRapportImpayes(residenceId, params = {}) {
    return api.get(`/residences/${residenceId}/rapports/impayes/`, { params })
  },

  // Rapport AG
  getRapportAG(assembleeId) {
    return api.get(`/assembles/${assembleeId}/rapport/`)
  },

  // Export rapport PDF
  exportPDF(residenceId, type, params = {}) {
    return api.get(`/residences/${residenceId}/rapports/${type}/export/`, {
      params,
      responseType: 'blob',
    })
  },

  // Export rapport Excel
  exportExcel(residenceId, type, params = {}) {
    return api.get(`/residences/${residenceId}/rapports/${type}/export/excel/`, {
      params,
      responseType: 'blob',
    })
  },

  // Statistiques globales
  getGlobalStats(params = {}) {
    return api.get('/rapports/stats/', { params })
  },
}
```

---

## Composants Core

### `src/components/common/Navbar.vue`

```vue
<template>
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary sticky-top">
    <div class="container-fluid">
      <router-link class="navbar-brand" to="/">
        <i class="bi bi-building me-2"></i>
        SyndicPro
      </router-link>

      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarNav"
      >
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav me-auto">
          <li class="nav-item">
            <router-link class="nav-link" to="/dashboard">
              <i class="bi bi-speedometer2 me-1"></i> Tableau de bord
            </router-link>
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/residences">
              <i class="bi bi-building me-1"></i> Résidences
            </router-link>
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/coproprietaires">
              <i class="bi bi-people me-1"></i> Copropriétaires
            </router-link>
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/finances">
              <i class="bi bi-cash-coin me-1"></i> Finances
            </router-link>
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/prestataires">
              <i class="bi bi-briefcase me-1"></i> Prestataires
            </router-link>
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/assembles">
              <i class="bi bi-calendar-event me-1"></i> Assemblées
            </router-link>
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/documents">
              <i class="bi bi-file-earmark-text me-1"></i> Documents
            </router-link>
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/rapports">
              <i class="bi bi-graph-up me-1"></i> Rapports
            </router-link>
          </li>
        </ul>

        <ul class="navbar-nav">
          <li class="nav-item dropdown" v-if="authStore.isAuthenticated">
            <a
              class="nav-link dropdown-toggle"
              href="#"
              role="button"
              data-bs-toggle="dropdown"
            >
              <i class="bi bi-person-circle me-1"></i>
              {{ authStore.user?.first_name }} {{ authStore.user?.last_name }}
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
              <li>
                <router-link class="dropdown-item" to="/profile">
                  <i class="bi bi-person me-2"></i>Mon Profil
                </router-link>
              </li>
              <li><hr class="dropdown-divider"></li>
              <li>
                <a class="dropdown-item" href="#" @click.prevent="handleLogout">
                  <i class="bi bi-box-arrow-right me-2"></i>Déconnexion
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item" v-else>
            <router-link class="btn btn-outline-light ms-2" to="/login">
              Connexion
            </router-link>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</template>

<script setup>
import { useAuthStore } from '@/stores/auth'
import { useRouter } from 'vue-router'
import { useToast } from 'vue-toastification'

const authStore = useAuthStore()
const router = useRouter()
const toast = useToast()

const handleLogout = async () => {
  try {
    await authStore.logout()
    toast.success('Déconnexion réussie')
    router.push('/login')
  } catch (error) {
    toast.error('Erreur lors de la déconnexion')
  }
}
</script>

<style scoped>
.navbar-brand {
  font-weight: 700;
  font-size: 1.5rem;
}

.nav-link {
  font-weight: 500;
  transition: all 0.3s ease;
}

.nav-link:hover {
  transform: translateY(-2px);
}

.nav-link.router-link-active {
  background-color: rgba(255, 255, 255, 0.2);
  border-radius: 5px;
}
</style>
```

### `src/components/common/LoadingSpinner.vue`

```vue
<template>
  <div class="d-flex justify-content-center align-items-center" :style="{ height }">
    <div class="spinner-border text-primary" role="status" :style="{ width: size, height: size }">
      <span class="visually-hidden">Chargement...</span>
    </div>
  </div>
</template>

<script setup>
defineProps({
  size: {
    type: String,
    default: '3rem',
  },
  height: {
    type: String,
    default: '200px',
  },
})
</script>
```

### `src/components/common/ErrorAlert.vue`

```vue
<template>
  <div v-if="message" class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="bi bi-exclamation-triangle-fill me-2"></i>
    {{ message }}
    <button
      type="button"
      class="btn-close"
      @click="$emit('dismiss')"
      aria-label="Close"
    ></button>
  </div>
</template>

<script setup>
defineProps({
  message: {
    type: String,
    default: '',
  },
})

defineEmits(['dismiss'])
</script>
```

---

## Modules de l'application

### 1. Module Dashboard

#### `src/views/dashboard/Dashboard.vue`

```vue
<template>
  <div class="dashboard-container">
    <!-- Page Header -->
    <div class="page-header mb-4">
      <div class="row align-items-center">
        <div class="col">
          <h2 class="page-title">
            <i class="bi bi-speedometer2 me-2"></i>
            Tableau de Bord
          </h2>
          <p class="text-muted">Bienvenue, {{ authStore.user?.first_name }}!</p>
        </div>
        <div class="col-auto">
          <select
            v-model="selectedResidence"
            class="form-select"
            @change="loadDashboardData"
          >
            <option value="">Toutes les résidences</option>
            <option v-for="res in residences" :key="res.id" :value="res.id">
              {{ res.nom }}
            </option>
          </select>
        </div>
      </div>
    </div>

    <!-- Loading State -->
    <LoadingSpinner v-if="loading" />

    <!-- Dashboard Content -->
    <div v-else>
      <!-- Stats Cards -->
      <div class="row g-4 mb-4">
        <div class="col-md-3">
          <StatCard
            title="Résidences"
            :value="stats.residences"
            icon="building"
            color="primary"
            :trend="{ value: 12, isPositive: true }"
          />
        </div>
        <div class="col-md-3">
          <StatCard
            title="Copropriétaires"
            :value="stats.coproprietaires"
            icon="people"
            color="success"
            :trend="{ value: 8, isPositive: true }"
          />
        </div>
        <div class="col-md-3">
          <StatCard
            title="Impayés"
            :value="formatCurrency(stats.impayes)"
            icon="exclamation-circle"
            color="danger"
          />
        </div>
        <div class="col-md-3">
          <StatCard
            title="Budget Annuel"
            :value="formatCurrency(stats.budget)"
            icon="cash-stack"
            color="info"
          />
        </div>
      </div>

      <!-- Alerts Row -->
      <div class="row mb-4" v-if="alerts.length > 0">
        <div class="col-12">
          <h5 class="mb-3">
            <i class="bi bi-bell me-2"></i>Alertes
          </h5>
          <div class="row g-3">
            <div class="col-md-6" v-for="alert in alerts" :key="alert.id">
              <AlertCard :alert="alert" @dismiss="dismissAlert(alert.id)" />
            </div>
          </div>
        </div>
      </div>

      <!-- Charts Row -->
      <div class="row g-4 mb-4">
        <div class="col-lg-8">
          <div class="card">
            <div class="card-header">
              <h5 class="card-title mb-0">
                <i class="bi bi-graph-up me-2"></i>Recettes vs Dépenses
              </h5>
            </div>
            <div class="card-body">
              <FinanceChart :data="financeData" type="bar" />
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="card">
            <div class="card-header">
              <h5 class="card-title mb-0">
                <i class="bi bi-pie-chart me-2"></i>Répartition des Dépenses
              </h5>
            </div>
            <div class="card-body">
              <FinanceChart :data="expenseData" type="pie" />
            </div>
          </div>
        </div>
      </div>

      <!-- Recent Activity & Upcoming -->
      <div class="row g-4">
        <div class="col-lg-6">
          <div class="card h-100">
            <div class="card-header">
              <h5 class="card-title mb-0">
                <i class="bi bi-clock-history me-2"></i>Activité Récente
              </h5>
            </div>
            <div class="card-body">
              <RecentActivity :activities="recentActivities" />
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="card h-100">
            <div class="card-header">
              <h5 class="card-title mb-0">
                <i class="bi bi-calendar-check me-2"></i>À Venir
              </h5>
            </div>
            <div class="card-body">
              <UpcomingList :events="upcomingEvents" />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useAuthStore } from '@/stores/auth'
import { residencesAPI } from '@/api/residences'
import { rapportsAPI } from '@/api/rapports'
import StatCard from '@/components/dashboard/StatCard.vue'
import AlertCard from '@/components/dashboard/AlertCard.vue'
import FinanceChart from '@/components/finances/FinanceChart.vue'
import RecentActivity from '@/components/dashboard/RecentActivity.vue'
import UpcomingList from '@/components/dashboard/UpcomingList.vue'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'
import { useToast } from 'vue-toastification'

const authStore = useAuthStore()
const toast = useToast()

const loading = ref(true)
const selectedResidence = ref('')
const residences = ref([])
const stats = ref({
  residences: 0,
  coproprietaires: 0,
  impayes: 0,
  budget: 0,
})
const alerts = ref([])
const financeData = ref([])
const expenseData = ref([])
const recentActivities = ref([])
const upcomingEvents = ref([])

const formatCurrency = (value) => {
  return new Intl.NumberFormat('fr-MA', {
    style: 'currency',
    currency: 'MAD',
  }).format(value)
}

const loadDashboardData = async () => {
  loading.value = true
  try {
    // Charger les résidences
    const resRes = await residencesAPI.getList()
    residences.value = resRes.data.results || resRes.data

    // Charger les stats globales
    const statsRes = await rapportsAPI.getGlobalStats()
    stats.value = statsRes.data

    // Charger les alertes
    alerts.value = statsRes.data.alertes || []

    // Charger les données financières
    if (selectedResidence.value) {
      const financeRes = await rapportsAPI.getBudgetVsReel(
        selectedResidence.value,
        new Date().getFullYear()
      )
      financeData.value = financeRes.data.mensuel
      expenseData.value = financeRes.data.repartition
    }

    // Charger l'activité récente
    recentActivities.value = statsRes.data.activites || []

    // Charger les événements à venir
    upcomingEvents.value = statsRes.data.a_venir || []
  } catch (error) {
    console.error('Erreur chargement dashboard:', error)
    toast.error('Erreur lors du chargement des données')
  } finally {
    loading.value = false
  }
}

const dismissAlert = async (alertId) => {
  alerts.value = alerts.value.filter((a) => a.id !== alertId)
  toast.success('Alerte ignorée')
}

onMounted(() => {
  loadDashboardData()
})
</script>

<style scoped>
.dashboard-container {
  padding: 20px;
}

.page-header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.page-title {
  font-weight: 700;
  margin: 0;
}

.card {
  border: none;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.12);
}

.card-header {
  background-color: #fff;
  border-bottom: 2px solid #f0f0f0;
  padding: 20px;
  border-radius: 12px 12px 0 0 !important;
}

.card-title {
  font-weight: 600;
  color: #333;
}
</style>
```

#### `src/components/dashboard/StatCard.vue`

```vue
<template>
  <div class="stat-card card h-100">
    <div class="card-body">
      <div class="d-flex align-items-center">
        <div
          class="stat-icon me-3"
          :class="`bg-${color}-light`"
        >
          <i :class="`bi bi-${icon} text-${color}`"></i>
        </div>
        <div class="flex-grow-1">
          <h6 class="stat-label text-muted mb-1">{{ title }}</h6>
          <h3 class="stat-value mb-0">{{ formattedValue }}</h3>
          <div v-if="trend" class="stat-trend mt-2">
            <span
              :class="trend.isPositive ? 'text-success' : 'text-danger'"
            >
              <i :class="trend.isPositive ? 'bi bi-arrow-up' : 'bi bi-arrow-down'"></i>
              {{ trend.value }}%
            </span>
            <span class="text-muted ms-1">vs mois dernier</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  title: {
    type: String,
    required: true,
  },
  value: {
    type: [Number, String],
    required: true,
  },
  icon: {
    type: String,
    required: true,
  },
  color: {
    type: String,
    default: 'primary',
  },
  trend: {
    type: Object,
    default: null,
  },
})

const formattedValue = computed(() => {
  return props.value
})
</script>

<style scoped>
.stat-card {
  border-radius: 12px;
  border: none;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  transition: all 0.3s ease;
}

.stat-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.12);
}

.stat-icon {
  width: 60px;
  height: 60px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5rem;
}

.stat-label {
  font-size: 0.875rem;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.stat-value {
  font-weight: 700;
  font-size: 1.75rem;
  color: #333;
}

.stat-trend {
  font-size: 0.875rem;
}
</style>
```

#### `src/components/dashboard/AlertCard.vue`

```vue
<template>
  <div
    class="alert-card"
    :class="`alert-${alert.type}`"
  >
    <div class="d-flex align-items-start">
      <div class="alert-icon me-3">
        <i :class="getIcon(alert.type)"></i>
      </div>
      <div class="flex-grow-1">
        <h6 class="alert-title mb-1">{{ alert.title }}</h6>
        <p class="alert-message mb-0">{{ alert.message }}</p>
        <small class="alert-time text-muted">{{ formatTime(alert.created_at) }}</small>
      </div>
      <button
        class="btn-close"
        @click="$emit('dismiss')"
        aria-label="Close"
      ></button>
    </div>
  </div>
</template>

<script setup>
import dayjs from 'dayjs'
import 'dayjs/locale/fr'
import relativeTime from 'dayjs/plugin/relativeTime'

dayjs.extend(relativeTime)
dayjs.locale('fr')

const props = defineProps({
  alert: {
    type: Object,
    required: true,
  },
})

defineEmits(['dismiss'])

const getIcon = (type) => {
  const icons = {
    warning: 'bi bi-exclamation-triangle-fill',
    danger: 'bi bi-x-circle-fill',
    success: 'bi bi-check-circle-fill',
    info: 'bi bi-info-circle-fill',
  }
  return icons[type] || icons.info
}

const formatTime = (date) => {
  return dayjs(date).fromNow()
}
</script>

<style scoped>
.alert-card {
  padding: 20px;
  border-radius: 12px;
  border: none;
  border-left: 4px solid;
}

.alert-warning {
  background-color: #fff3cd;
  border-left-color: #ffc107;
}

.alert-danger {
  background-color: #f8d7da;
  border-left-color: #dc3545;
}

.alert-success {
  background-color: #d4edda;
  border-left-color: #28a745;
}

.alert-info {
  background-color: #d1ecf1;
  border-left-color: #17a2b8;
}

.alert-icon {
  font-size: 1.5rem;
}

.alert-title {
  font-weight: 600;
  color: #333;
}

.alert-message {
  font-size: 0.9rem;
  color: #666;
}

.alert-time {
  font-size: 0.75rem;
}
</style>
```

### 2. Module Copropriétaires

#### `src/views/coproprietaires/CoproprietaireList.vue`

```vue
<template>
  <div class="coproprietaires-container">
    <!-- Page Header -->
    <div class="page-header mb-4">
      <div class="row align-items-center">
        <div class="col">
          <h2 class="page-title">
            <i class="bi bi-people me-2"></i>
            Copropriétaires
          </h2>
        </div>
        <div class="col-auto">
          <button
            class="btn btn-primary"
            data-bs-toggle="modal"
            data-bs-target="#addModal"
          >
            <i class="bi bi-plus-lg me-2"></i>Ajouter
          </button>
        </div>
      </div>
    </div>

    <!-- Filters -->
    <div class="card mb-4">
      <div class="card-body">
        <div class="row g-3">
          <div class="col-md-4">
            <input
              v-model="searchQuery"
              type="text"
              class="form-control"
              placeholder="Rechercher..."
              @input="handleSearch"
            >
          </div>
          <div class="col-md-3">
            <select v-model="filterResidence" class="form-select" @change="loadCoproprietaires">
              <option value="">Toutes les résidences</option>
              <option v-for="res in residences" :key="res.id" :value="res.id">
                {{ res.nom }}
              </option>
            </select>
          </div>
          <div class="col-md-3">
            <select v-model="filterStatut" class="form-select" @change="loadCoproprietaires">
              <option value="">Tous les statuts</option>
              <option value="actif">Actif</option>
              <option value="inactif">Inactif</option>
            </select>
          </div>
          <div class="col-md-2">
            <button class="btn btn-outline-secondary w-100" @click="resetFilters">
              <i class="bi bi-x-circle me-1"></i>Réinitialiser
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Loading -->
    <LoadingSpinner v-if="loading" />

    <!-- Results -->
    <div v-else>
      <!-- Table View -->
      <div class="card">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th @click="sortBy('nom')" class="sortable">
                    Nom
                    <i v-if="sortField === 'nom'" :class="sortOrder === 'asc' ? 'bi bi-sort-up' : 'bi bi-sort-down'"></i>
                  </th>
                  <th>Appartement</th>
                  <th @click="sortBy('quote_part')" class="sortable">
                    Quote-part
                    <i v-if="sortField === 'quote_part'" :class="sortOrder === 'asc' ? 'bi bi-sort-up' : 'bi bi-sort-down'"></i>
                  </th>
                  <th>Contact</th>
                  <th>Statut</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="copro in coproprietaires" :key="copro.id">
                  <td>
                    <router-link :to="`/coproprietaires/${copro.id}`" class="text-decoration-none">
                      <strong>{{ copro.nom }} {{ copro.prenom }}</strong>
                    </router-link>
                  </td>
                  <td>{{ copro.appartement }}</td>
                  <td>{{ copro.quote_part }}%</td>
                  <td>
                    <div class="contact-info">
                      <div v-if="copro.email">
                        <i class="bi bi-envelope me-1"></i>{{ copro.email }}
                      </div>
                      <div v-if="copro.telephone">
                        <i class="bi bi-telephone me-1"></i>{{ copro.telephone }}
                      </div>
                    </div>
                  </td>
                  <td>
                    <span
                      class="badge"
                      :class="copro.statut === 'actif' ? 'bg-success' : 'bg-secondary'"
                    >
                      {{ copro.statut }}
                    </span>
                  </td>
                  <td>
                    <div class="btn-group">
                      <button
                        class="btn btn-sm btn-outline-primary"
                        @click="viewDetails(copro)"
                        title="Voir"
                      >
                        <i class="bi bi-eye"></i>
                      </button>
                      <button
                        class="btn btn-sm btn-outline-secondary"
                        @click="editCopro(copro)"
                        title="Modifier"
                      >
                        <i class="bi bi-pencil"></i>
                      </button>
                      <button
                        class="btn btn-sm btn-outline-danger"
                        @click="deleteCopro(copro)"
                        title="Supprimer"
                      >
                        <i class="bi bi-trash"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <!-- Pagination -->
          <nav v-if="pagination.totalPages > 1">
            <ul class="pagination justify-content-center">
              <li class="page-item" :class="{ disabled: pagination.page === 1 }">
                <a
                  class="page-link"
                  href="#"
                  @click.prevent="changePage(pagination.page - 1)"
                >
                  <i class="bi bi-chevron-left"></i>
                </a>
              </li>
              <li
                v-for="page in pagination.totalPages"
                :key="page"
                class="page-item"
                :class="{ active: page === pagination.page }"
              >
                <a
                  class="page-link"
                  href="#"
                  @click.prevent="changePage(page)"
                >
                  {{ page }}
                </a>
              </li>
              <li class="page-item" :class="{ disabled: pagination.page === pagination.totalPages }">
                <a
                  class="page-link"
                  href="#"
                  @click.prevent="changePage(pagination.page + 1)"
                >
                  <i class="bi bi-chevron-right"></i>
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </div>

    <!-- Add/Edit Modal -->
    <div
      class="modal fade"
      id="addModal"
      tabindex="-1"
      ref="addModal"
    >
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">
              {{ editingCopro ? 'Modifier' : 'Ajouter' }} un copropriétaire
            </h5>
            <button
              type="button"
              class="btn-close"
              data-bs-dismiss="modal"
            ></button>
          </div>
          <div class="modal-body">
            <CoproprietaireForm
              :coproprietaire="editingCopro"
              :residences="residences"
              @submit="handleSubmit"
              @cancel="closeModal"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { Modal } from 'bootstrap'
import { coproprietairesAPI } from '@/api/coproprietaires'
import { residencesAPI } from '@/api/residences'
import CoproprietaireForm from '@/components/coproprietaires/CoproprietaireForm.vue'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'
import { useToast } from 'vue-toastification'
import Swal from 'sweetalert2'

const router = useRouter()
const toast = useToast()

const loading = ref(false)
const coproprietaires = ref([])
const residences = ref([])
const searchQuery = ref('')
const filterResidence = ref('')
const filterStatut = ref('')
const sortField = ref('nom')
const sortOrder = ref('asc')
const pagination = ref({
  page: 1,
  totalPages: 1,
  total: 0,
})
const editingCopro = ref(null)
let addModalInstance = null
const addModal = ref(null)

const loadCoproprietaires = async () => {
  loading.value = true
  try {
    const params = {
      page: pagination.value.page,
      search: searchQuery.value,
      residence: filterResidence.value,
      statut: filterStatut.value,
      ordering: `${sortOrder.value === 'desc' ? '-' : ''}${sortField.value}`,
    }

    const response = await coproprietairesAPI.getList(params)
    coproprietaires.value = response.data.results || response.data
    pagination.value = {
      page: response.data.page || 1,
      totalPages: Math.ceil((response.data.count || response.data.length) / (response.data.page_size || 20)),
      total: response.data.count || response.data.length,
    }
  } catch (error) {
    console.error('Erreur chargement copropriétaires:', error)
    toast.error('Erreur lors du chargement des copropriétaires')
  } finally {
    loading.value = false
  }
}

const loadResidences = async () => {
  try {
    const response = await residencesAPI.getList()
    residences.value = response.data.results || response.data
  } catch (error) {
    console.error('Erreur chargement résidences:', error)
  }
}

const handleSearch = debounce(() => {
  pagination.value.page = 1
  loadCoproprietaires()
}, 500)

const sortBy = (field) => {
  if (sortField.value === field) {
    sortOrder.value = sortOrder.value === 'asc' ? 'desc' : 'asc'
  } else {
    sortField.value = field
    sortOrder.value = 'asc'
  }
  loadCoproprietaires()
}

const changePage = (page) => {
  if (page >= 1 && page <= pagination.value.totalPages) {
    pagination.value.page = page
    loadCoproprietaires()
  }
}

const resetFilters = () => {
  searchQuery.value = ''
  filterResidence.value = ''
  filterStatut.value = ''
  pagination.value.page = 1
  loadCoproprietaires()
}

const viewDetails = (copro) => {
  router.push(`/coproprietaires/${copro.id}`)
}

const editCopro = (copro) => {
  editingCopro.value = { ...copro }
  openModal()
}

const deleteCopro = async (copro) => {
  const result = await Swal.fire({
    title: 'Êtes-vous sûr?',
    text: `Voulez-vous vraiment supprimer ${copro.nom} ${copro.prenom}?`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#dc3545',
    cancelButtonColor: '#6c757d',
    confirmButtonText: 'Oui, supprimer',
    cancelButtonText: 'Annuler',
  })

  if (result.isConfirmed) {
    try {
      await coproprietairesAPI.delete(copro.id)
      toast.success('Copropriétaire supprimé avec succès')
      loadCoproprietaires()
    } catch (error) {
      toast.error('Erreur lors de la suppression')
    }
  }
}

const openModal = () => {
  if (!addModalInstance) {
    addModalInstance = new Modal(addModal.value)
  }
  addModalInstance.show()
}

const closeModal = () => {
  if (addModalInstance) {
    addModalInstance.hide()
  }
  editingCopro.value = null
}

const handleSubmit = async (formData) => {
  try {
    if (editingCopro.value) {
      await coproprietairesAPI.update(editingCopro.value.id, formData)
      toast.success('Copropriétaire modifié avec succès')
    } else {
      await coproprietairesAPI.create(formData)
      toast.success('Copropriétaire ajouté avec succès')
    }
    closeModal()
    loadCoproprietaires()
  } catch (error) {
    toast.error('Erreur lors de l\'enregistrement')
  }
}

// Debounce helper
function debounce(func, wait) {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

onMounted(() => {
  loadResidences()
  loadCoproprietaires()

  nextTick(() => {
    const modalElement = document.getElementById('addModal')
    if (modalElement) {
      addModalInstance = new Modal(modalElement)
    }
  })
})
</script>

<style scoped>
.coproprietaires-container {
  padding: 20px;
}

.page-header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.contact-info {
  font-size: 0.85rem;
  color: #666;
}

.contact-info div {
  margin-bottom: 2px;
}

.sortable {
  cursor: pointer;
  user-select: none;
}

.sortable:hover {
  background-color: #f8f9fa;
}
</style>
```

#### `src/components/coproprietaires/CoproprietaireForm.vue`

```vue
<template>
  <form @submit.prevent="onSubmit">
    <div class="row g-3">
      <!-- Informations personnelles -->
      <div class="col-12">
        <h6 class="text-primary mb-3">
          <i class="bi bi-person me-2"></i>Informations personnelles
        </h6>
      </div>

      <div class="col-md-6">
        <label class="form-label">Nom *</label>
        <input
          v-model="form.nom"
          type="text"
          class="form-control"
          :class="{ 'is-invalid': errors.nom }"
          required
        >
        <div class="invalid-feedback">{{ errors.nom }}</div>
      </div>

      <div class="col-md-6">
        <label class="form-label">Prénom *</label>
        <input
          v-model="form.prenom"
          type="text"
          class="form-control"
          :class="{ 'is-invalid': errors.prenom }"
          required
        >
        <div class="invalid-feedback">{{ errors.prenom }}</div>
      </div>

      <div class="col-md-6">
        <label class="form-label">Email</label>
        <input
          v-model="form.email"
          type="email"
          class="form-control"
          :class="{ 'is-invalid': errors.email }"
        >
        <div class="invalid-feedback">{{ errors.email }}</div>
      </div>

      <div class="col-md-6">
        <label class="form-label">Téléphone</label>
        <input
          v-model="form.telephone"
          type="tel"
          class="form-control"
          :class="{ 'is-invalid': errors.telephone }"
        >
        <div class="invalid-feedback">{{ errors.telephone }}</div>
      </div>

      <!-- Informations appartement -->
      <div class="col-12 mt-4">
        <h6 class="text-primary mb-3">
          <i class="bi bi-house me-2"></i>Appartement
        </h6>
      </div>

      <div class="col-md-6">
        <label class="form-label">Résidence *</label>
        <select
          v-model="form.residence"
          class="form-select"
          :class="{ 'is-invalid': errors.residence }"
          required
        >
          <option value="">Sélectionner une résidence</option>
          <option v-for="res in residences" :key="res.id" :value="res.id">
            {{ res.nom }}
          </option>
        </select>
        <div class="invalid-feedback">{{ errors.residence }}</div>
      </div>

      <div class="col-md-6">
        <label class="form-label">Appartement *</label>
        <input
          v-model="form.appartement"
          type="text"
          class="form-control"
          :class="{ 'is-invalid': errors.appartement }"
          placeholder="Ex: A-101"
          required
        >
        <div class="invalid-feedback">{{ errors.appartement }}</div>
      </div>

      <div class="col-md-6">
        <label class="form-label">Étage</label>
        <input
          v-model="form.etage"
          type="number"
          class="form-control"
          :class="{ 'is-invalid': errors.etage }"
          min="0"
        >
        <div class="invalid-feedback">{{ errors.etage }}</div>
      </div>

      <div class="col-md-6">
        <label class="form-label">Quote-part (%) *</label>
        <input
          v-model.number="form.quote_part"
          type="number"
          class="form-control"
          :class="{ 'is-invalid': errors.quote_part }"
          step="0.01"
          min="0"
          max="100"
          required
        >
        <div class="invalid-feedback">{{ errors.quote_part }}</div>
      </div>

      <!-- Adresse -->
      <div class="col-12 mt-4">
        <h6 class="text-primary mb-3">
          <i class="bi bi-geo-alt me-2"></i>Adresse
        </h6>
      </div>

      <div class="col-12">
        <label class="form-label">Adresse</label>
        <input
          v-model="form.adresse"
          type="text"
          class="form-control"
          :class="{ 'is-invalid': errors.adresse }"
        >
        <div class="invalid-feedback">{{ errors.adresse }}</div>
      </div>

      <div class="col-md-4">
        <label class="form-label">Code postal</label>
        <input
          v-model="form.code_postal"
          type="text"
          class="form-control"
          :class="{ 'is-invalid': errors.code_postal }"
        >
        <div class="invalid-feedback">{{ errors.code_postal }}</div>
      </div>

      <div class="col-md-4">
        <label class="form-label">Ville</label>
        <input
          v-model="form.ville"
          type="text"
          class="form-control"
          :class="{ 'is-invalid': errors.ville }"
        >
        <div class="invalid-feedback">{{ errors.ville }}</div>
      </div>

      <div class="col-md-4">
        <label class="form-label">Pays</label>
        <input
          v-model="form.pays"
          type="text"
          class="form-control"
          :class="{ 'is-invalid': errors.pays }"
          value="Maroc"
        >
        <div class="invalid-feedback">{{ errors.pays }}</div>
      </div>

      <!-- Statut -->
      <div class="col-12 mt-4">
        <h6 class="text-primary mb-3">
          <i class="bi bi-gear me-2"></i>Statut
        </h6>
      </div>

      <div class="col-md-6">
        <label class="form-label">Statut *</label>
        <select
          v-model="form.statut"
          class="form-select"
          :class="{ 'is-invalid': errors.statut }"
          required
        >
          <option value="actif">Actif</option>
          <option value="inactif">Inactif</option>
        </select>
        <div class="invalid-feedback">{{ errors.statut }}</div>
      </div>

      <div class="col-md-6">
        <label class="form-label">Date d'entrée</label>
        <input
          v-model="form.date_entree"
          type="date"
          class="form-control"
          :class="{ 'is-invalid': errors.date_entree }"
        >
        <div class="invalid-feedback">{{ errors.date_entree }}</div>
      </div>

      <!-- Notes -->
      <div class="col-12 mt-4">
        <label class="form-label">Notes</label>
        <textarea
          v-model="form.notes"
          class="form-control"
          rows="3"
          placeholder="Notes supplémentaires..."
        ></textarea>
      </div>
    </div>

    <!-- Actions -->
    <div class="d-flex justify-content-end gap-2 mt-4">
      <button type="button" class="btn btn-secondary" @click="$emit('cancel')">
        Annuler
      </button>
      <button type="submit" class="btn btn-primary" :disabled="submitting">
        <span v-if="submitting" class="spinner-border spinner-border-sm me-2"></span>
        {{ submitting ? 'Enregistrement...' : 'Enregistrer' }}
      </button>
    </div>
  </form>
</template>

<script setup>
import { ref, reactive, watch, onMounted } from 'vue'
import { useToast } from 'vue-toastification'

const props = defineProps({
  coproprietaire: {
    type: Object,
    default: null,
  },
  residences: {
    type: Array,
    default: () => [],
  },
})

const emit = defineEmits(['submit', 'cancel'])

const toast = useToast()
const submitting = ref(false)
const errors = reactive({})

const form = reactive({
  nom: '',
  prenom: '',
  email: '',
  telephone: '',
  residence: '',
  appartement: '',
  etage: '',
  quote_part: 0,
  adresse: '',
  code_postal: '',
  ville: '',
  pays: 'Maroc',
  statut: 'actif',
  date_entree: '',
  notes: '',
})

// Populate form if editing
watch(() => props.coproprietaire, (newVal) => {
  if (newVal) {
    Object.assign(form, {
      nom: newVal.nom || '',
      prenom: newVal.prenom || '',
      email: newVal.email || '',
      telephone: newVal.telephone || '',
      residence: newVal.residence || '',
      appartement: newVal.appartement || '',
      etage: newVal.etage || '',
      quote_part: newVal.quote_part || 0,
      adresse: newVal.adresse || '',
      code_postal: newVal.code_postal || '',
      ville: newVal.ville || '',
      pays: newVal.pays || 'Maroc',
      statut: newVal.statut || 'actif',
      date_entree: newVal.date_entree || '',
      notes: newVal.notes || '',
    })
  }
}, { immediate: true })

const validateForm = () => {
  Object.keys(errors).forEach(key => delete errors[key])

  if (!form.nom) errors.nom = 'Le nom est requis'
  if (!form.prenom) errors.prenom = 'Le prénom est requis'
  if (form.email && !/\S+@\S+\.\S+/.test(form.email)) {
    errors.email = 'Email invalide'
  }
  if (!form.residence) errors.residence = 'La résidence est requise'
  if (!form.appartement) errors.appartement = 'L\'appartement est requis'
  if (form.quote_part < 0 || form.quote_part > 100) {
    errors.quote_part = 'La quote-part doit être entre 0 et 100'
  }

  return Object.keys(errors).length === 0
}

const onSubmit = async () => {
  if (!validateForm()) {
    toast.error('Veuillez corriger les erreurs')
    return
  }

  submitting.value = true
  try {
    // Create FormData for file upload if needed
    const formData = new FormData()
    Object.keys(form).forEach(key => {
      if (form[key] !== null && form[key] !== '') {
        formData.append(key, form[key])
      }
    })

    emit('submit', formData)
  } finally {
    submitting.value = false
  }
}
</script>

<style scoped>
.form-label {
  font-weight: 500;
  color: #555;
}

h6 {
  font-weight: 600;
  border-bottom: 2px solid #e9ecef;
  padding-bottom: 10px;
}
</style>
```

### 3. Module Financier

#### `src/views/finances/Finances.vue`

```vue
<template>
  <div class="finances-container">
    <!-- Page Header -->
    <div class="page-header mb-4">
      <div class="row align-items-center">
        <div class="col">
          <h2 class="page-title">
            <i class="bi bi-cash-coin me-2"></i>
            Finances
          </h2>
        </div>
        <div class="col-auto">
          <div class="btn-group">
            <button
              class="btn"
              :class="activeTab === 'overview' ? 'btn-primary' : 'btn-outline-primary'"
              @click="activeTab = 'overview'"
            >
              Vue d'ensemble
            </button>
            <button
              class="btn"
              :class="activeTab === 'budget' ? 'btn-primary' : 'btn-outline-primary'"
              @click="activeTab = 'budget'"
            >
              Budget
            </button>
            <button
              class="btn"
              :class="activeTab === 'appels' ? 'btn-primary' : 'btn-outline-primary'"
              @click="activeTab = 'appels'"
            >
              Appels de fonds
            </button>
            <button
              class="btn"
              :class="activeTab === 'comptabilite' ? 'btn-primary' : 'btn-outline-primary'"
              @click="activeTab = 'comptabilite'"
            >
              Comptabilité
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Residence Selector -->
    <div class="card mb-4">
      <div class="card-body">
        <div class="row align-items-center">
          <div class="col-md-6">
            <label class="form-label fw-bold">Sélectionner une résidence:</label>
            <select
              v-model="selectedResidence"
              class="form-select"
              @change="loadFinanceData"
            >
              <option value="">Sélectionner une résidence</option>
              <option v-for="res in residences" :key="res.id" :value="res.id">
                {{ res.nom }}
              </option>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label fw-bold">Année:</label>
            <select
              v-model="selectedYear"
              class="form-select"
              @change="loadFinanceData"
            >
              <option v-for="year in availableYears" :key="year" :value="year">
                {{ year }}
              </option>
            </select>
          </div>
        </div>
      </div>
    </div>

    <!-- Loading -->
    <LoadingSpinner v-if="loading" />

    <!-- Content -->
    <div v-else-if="selectedResidence">
      <!-- Overview Tab -->
      <div v-if="activeTab === 'overview'">
        <FinancialOverview
          :residence-id="selectedResidence"
          :year="selectedYear"
          :stats="financeStats"
        />
      </div>

      <!-- Budget Tab -->
      <div v-if="activeTab === 'budget'">
        <BudgetView
          :residence-id="selectedResidence"
          :year="selectedYear"
        />
      </div>

      <!-- Appels de Fonds Tab -->
      <div v-if="activeTab === 'appels'">
        <AppelsFondsView
          :residence-id="selectedResidence"
        />
      </div>

      <!-- Comptabilité Tab -->
      <div v-if="activeTab === 'comptabilite'">
        <ComptabiliteView
          :residence-id="selectedResidence"
          :year="selectedYear"
        />
      </div>
    </div>

    <!-- No residence selected -->
    <div v-else class="text-center py-5">
      <i class="bi bi-building text-muted" style="font-size: 4rem;"></i>
      <p class="text-muted mt-3">Veuillez sélectionner une résidence pour voir les finances</p>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { residencesAPI } from '@/api/residences'
import { financesAPI } from '@/api/finances'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'
import FinancialOverview from '@/components/finances/FinancialOverview.vue'
import BudgetView from '@/components/finances/BudgetView.vue'
import AppelsFondsView from '@/components/finances/AppelsFondsView.vue'
import ComptabiliteView from '@/components/finances/ComptabiliteView.vue'
import { useToast } from 'vue-toastification'

const toast = useToast()

const activeTab = ref('overview')
const loading = ref(false)
const selectedResidence = ref('')
const selectedYear = ref(new Date().getFullYear())
const residences = ref([])
const financeStats = ref(null)

const availableYears = computed(() => {
  const currentYear = new Date().getFullYear()
  return Array.from({ length: 5 }, (_, i) => currentYear - i)
})

const loadResidences = async () => {
  try {
    const response = await residencesAPI.getList()
    residences.value = response.data.results || response.data
  } catch (error) {
    console.error('Erreur chargement résidences:', error)
    toast.error('Erreur lors du chargement des résidences')
  }
}

const loadFinanceData = async () => {
  if (!selectedResidence.value) return

  loading.value = true
  try {
    const stats = await financesAPI.getStats(selectedResidence.value, selectedYear.value)
    financeStats.value = stats.data
  } catch (error) {
    console.error('Erreur chargement données financières:', error)
    toast.error('Erreur lors du chargement des données financières')
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  loadResidences()
})
</script>

<style scoped>
.finances-container {
  padding: 20px;
}

.page-header {
  background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
  color: white;
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.page-title {
  font-weight: 700;
  margin: 0;
}

.btn-group .btn {
  border-radius: 8px;
  margin: 0 2px;
}
</style>
```

#### `src/components/finances/BudgetCard.vue`

```vue
<template>
  <div class="budget-card card h-100">
    <div class="card-header">
      <div class="d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">
          <i class="bi bi-pie-chart me-2"></i>
          Budget {{ budget.annee }}
        </h5>
        <span
          class="badge"
          :class="badgeClass"
        >
          {{ budget.statut }}
        </span>
      </div>
    </div>
    <div class="card-body">
      <div class="budget-metrics">
        <div class="metric">
          <label>Recettes prévues</label>
          <div class="value text-success">{{ formatCurrency(budget.recettes_prevues) }}</div>
        </div>
        <div class="metric">
          <label>Dépenses prévues</label>
          <div class="value text-danger">{{ formatCurrency(budget.depenses_prevues) }}</div>
        </div>
        <div class="metric">
          <label>Solde prévu</label>
          <div class="value" :class="budget.solde_prevu >= 0 ? 'text-primary' : 'text-danger'">
            {{ formatCurrency(budget.solde_prevu) }}
          </div>
        </div>
      </div>

      <!-- Progress bar -->
      <div class="mt-4">
        <label class="form-label">Exécution du budget</label>
        <div class="progress" style="height: 25px;">
          <div
            class="progress-bar"
            :class="progressBarClass"
            role="progressbar"
            :style="{ width: `${executionPercentage}%` }"
          >
            {{ executionPercentage }}%
          </div>
        </div>
        <small class="text-muted">
          {{ formatCurrency(budget.realise || 0) }} / {{ formatCurrency(budget.depenses_prevues) }}
        </small>
      </div>

      <!-- Budget lines preview -->
      <div class="mt-4" v-if="budget.lignes && budget.lignes.length > 0">
        <label class="form-label">Postes de dépenses</label>
        <div class="budget-lines">
          <div
            v-for="ligne in budget.lignes.slice(0, 5)"
            :key="ligne.id"
            class="budget-line"
          >
            <span class="categorie">{{ ligne.categorie }}</span>
            <span class="montant">{{ formatCurrency(ligne.montant) }}</span>
          </div>
          <div v-if="budget.lignes.length > 5" class="text-muted text-center mt-2">
            + {{ budget.lignes.length - 5 }} autres postes
          </div>
        </div>
      </div>
    </div>
    <div class="card-footer">
      <div class="d-flex justify-content-between align-items-center">
        <small class="text-muted">
          Approuvé le {{ formatDate(budget.date_approuve) }}
        </small>
        <div class="btn-group">
          <button
            class="btn btn-sm btn-outline-primary"
            @click="$emit('view', budget)"
            title="Voir détails"
          >
            <i class="bi bi-eye"></i>
          </button>
          <button
            class="btn btn-sm btn-outline-secondary"
            @click="$emit('edit', budget)"
            title="Modifier"
          >
            <i class="bi bi-pencil"></i>
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import dayjs from 'dayjs'
import 'dayjs/locale/fr'

dayjs.locale('fr')

const props = defineProps({
  budget: {
    type: Object,
    required: true,
  },
})

defineEmits(['view', 'edit'])

const formatCurrency = (value) => {
  return new Intl.NumberFormat('fr-MA', {
    style: 'currency',
    currency: 'MAD',
  }).format(value)
}

const formatDate = (date) => {
  return dayjs(date).format('DD MMMM YYYY')
}

const badgeClass = computed(() => {
  const statusClasses = {
    approuve: 'bg-success',
    en_cours: 'bg-warning',
    depasse: 'bg-danger',
  }
  return statusClasses[props.budget.statut] || 'bg-secondary'
})

const progressBarClass = computed(() => {
  if (props.executionPercentage > 100) return 'bg-danger'
  if (props.executionPercentage > 80) return 'bg-warning'
  return 'bg-success'
})

const executionPercentage = computed(() => {
  if (!props.budget.depenses_prevues || props.budget.depenses_prevues === 0) return 0
  const percentage = ((props.budget.realise || 0) / props.budget.depenses_prevues) * 100
  return Math.round(percentage)
})
</script>

<style scoped>
.budget-card {
  border: none;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.budget-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.12);
}

.card-header {
  background-color: #fff;
  border-bottom: 2px solid #f0f0f0;
  padding: 20px;
  border-radius: 12px 12px 0 0 !important;
}

.budget-metrics {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 15px;
}

.metric label {
  display: block;
  font-size: 0.75rem;
  text-transform: uppercase;
  color: #6c757d;
  font-weight: 600;
  margin-bottom: 5px;
}

.metric .value {
  font-size: 1.25rem;
  font-weight: 700;
}

.budget-lines {
  max-height: 200px;
  overflow-y: auto;
}

.budget-line {
  display: flex;
  justify-content: space-between;
  padding: 8px 0;
  border-bottom: 1px solid #f0f0f0;
}

.budget-line:last-child {
  border-bottom: none;
}

.budget-line .categorie {
  font-weight: 500;
}

.budget-line .montant {
  font-weight: 600;
  color: #333;
}

.card-footer {
  background-color: #f8f9fa;
  border-top: 1px solid #f0f0f0;
  padding: 15px 20px;
  border-radius: 0 0 12px 12px !important;
}

.progress {
  border-radius: 10px;
  background-color: #e9ecef;
}

.progress-bar {
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
```

### 4. Module Prestataires

#### `src/views/prestataires/PrestataireList.vue`

```vue
<template>
  <div class="prestataires-container">
    <!-- Page Header -->
    <div class="page-header mb-4">
      <div class="row align-items-center">
        <div class="col">
          <h2 class="page-title">
            <i class="bi bi-briefcase me-2"></i>
            Prestataires
          </h2>
        </div>
        <div class="col-auto">
          <button
            class="btn btn-primary"
            data-bs-toggle="modal"
            data-bs-target="#addModal"
          >
            <i class="bi bi-plus-lg me-2"></i>Ajouter
          </button>
        </div>
      </div>
    </div>

    <!-- Filters -->
    <div class="card mb-4">
      <div class="card-body">
        <div class="row g-3">
          <div class="col-md-4">
            <input
              v-model="searchQuery"
              type="text"
              class="form-control"
              placeholder="Rechercher un prestataire..."
              @input="handleSearch"
            >
          </div>
          <div class="col-md-3">
            <select v-model="filterService" class="form-select" @change="loadPrestataires">
              <option value="">Tous les services</option>
              <option value="ascenseur">Ascenseur</option>
              <option value="electricite">Électricité</option>
              <option value="plomberie">Plomberie</option>
              <option value="jardinage">Jardinage</option>
              <option value="nettoyage">Nettoyage</option>
              <option value="securite">Sécurité</option>
              <option value="autre">Autre</option>
            </select>
          </div>
          <div class="col-md-3">
            <select v-model="filterResidence" class="form-select" @change="loadPrestataires">
              <option value="">Toutes les résidences</option>
              <option v-for="res in residences" :key="res.id" :value="res.id">
                {{ res.nom }}
              </option>
            </select>
          </div>
          <div class="col-md-2">
            <button class="btn btn-outline-secondary w-100" @click="resetFilters">
              <i class="bi bi-x-circle me-1"></i>Réinitialiser
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Loading -->
    <LoadingSpinner v-if="loading" />

    <!-- Grid View -->
    <div v-else class="row g-4">
      <div
        v-for="prestataire in prestataires"
        :key="prestataire.id"
        class="col-md-6 col-lg-4"
      >
        <PrestataireCard
          :prestataire="prestataire"
          @view="viewDetails"
          @edit="editPrestataire"
          @delete="deletePrestataire"
        />
      </div>
    </div>

    <!-- Pagination -->
    <div v-if="pagination.totalPages > 1" class="d-flex justify-content-center mt-4">
      <nav>
        <ul class="pagination">
          <li class="page-item" :class="{ disabled: pagination.page === 1 }">
            <a
              class="page-link"
              href="#"
              @click.prevent="changePage(pagination.page - 1)"
            >
              <i class="bi bi-chevron-left"></i>
            </a>
          </li>
          <li
            v-for="page in displayedPages"
            :key="page"
            class="page-item"
            :class="{ active: page === pagination.page }"
          >
            <a
              class="page-link"
              href="#"
              @click.prevent="changePage(page)"
            >
              {{ page }}
            </a>
          </li>
          <li class="page-item" :class="{ disabled: pagination.page === pagination.totalPages }">
            <a
              class="page-link"
              href="#"
              @click.prevent="changePage(pagination.page + 1)"
            >
              <i class="bi bi-chevron-right"></i>
            </a>
          </li>
        </ul>
      </nav>
    </div>

    <!-- Add/Edit Modal -->
    <div
      class="modal fade"
      id="addModal"
      tabindex="-1"
      ref="addModal"
    >
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">
              {{ editingPrestataire ? 'Modifier' : 'Ajouter' }} un prestataire
            </h5>
            <button
              type="button"
              class="btn-close"
              data-bs-dismiss="modal"
            ></button>
          </div>
          <div class="modal-body">
            <PrestataireForm
              :prestataire="editingPrestataire"
              :residences="residences"
              @submit="handleSubmit"
              @cancel="closeModal"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { Modal } from 'bootstrap'
import { prestatairesAPI } from '@/api/prestataires'
import { residencesAPI } from '@/api/residences'
import PrestataireCard from '@/components/prestataires/PrestataireCard.vue'
import PrestataireForm from '@/components/prestataires/PrestataireForm.vue'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'
import { useToast } from 'vue-toastification'
import Swal from 'sweetalert2'

const router = useRouter()
const toast = useToast()

const loading = ref(false)
const prestataires = ref([])
const residences = ref([])
const searchQuery = ref('')
const filterService = ref('')
const filterResidence = ref('')
const pagination = ref({
  page: 1,
  totalPages: 1,
  total: 0,
})
const editingPrestataire = ref(null)
let addModalInstance = null
const addModal = ref(null)

const displayedPages = computed(() => {
  const pages = []
  const maxVisible = 5
  let start = Math.max(1, pagination.value.page - Math.floor(maxVisible / 2))
  let end = Math.min(pagination.value.totalPages, start + maxVisible - 1)

  if (end - start < maxVisible - 1) {
    start = Math.max(1, end - maxVisible + 1)
  }

  for (let i = start; i <= end; i++) {
    pages.push(i)
  }

  return pages
})

const loadPrestataires = async () => {
  loading.value = true
  try {
    const params = {
      page: pagination.value.page,
      search: searchQuery.value,
      service: filterService.value,
      residence: filterResidence.value,
    }

    const response = await prestatairesAPI.getList(params)
    prestataires.value = response.data.results || response.data
    pagination.value = {
      page: response.data.page || 1,
      totalPages: Math.ceil((response.data.count || response.data.length) / (response.data.page_size || 12)),
      total: response.data.count || response.data.length,
    }
  } catch (error) {
    console.error('Erreur chargement prestataires:', error)
    toast.error('Erreur lors du chargement des prestataires')
  } finally {
    loading.value = false
  }
}

const loadResidences = async () => {
  try {
    const response = await residencesAPI.getList()
    residences.value = response.data.results || response.data
  } catch (error) {
    console.error('Erreur chargement résidences:', error)
  }
}

const handleSearch = debounce(() => {
  pagination.value.page = 1
  loadPrestataires()
}, 500)

const changePage = (page) => {
  if (page >= 1 && page <= pagination.value.totalPages) {
    pagination.value.page = page
    loadPrestataires()
  }
}

const resetFilters = () => {
  searchQuery.value = ''
  filterService.value = ''
  filterResidence.value = ''
  pagination.value.page = 1
  loadPrestataires()
}

const viewDetails = (prestataire) => {
  router.push(`/prestataires/${prestataire.id}`)
}

const editPrestataire = (prestataire) => {
  editingPrestataire.value = { ...prestataire }
  openModal()
}

const deletePrestataire = async (prestataire) => {
  const result = await Swal.fire({
    title: 'Êtes-vous sûr?',
    text: `Voulez-vous vraiment supprimer ${prestataire.nom}?`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#dc3545',
    cancelButtonColor: '#6c757d',
    confirmButtonText: 'Oui, supprimer',
    cancelButtonText: 'Annuler',
  })

  if (result.isConfirmed) {
    try {
      await prestatairesAPI.delete(prestataire.id)
      toast.success('Prestataire supprimé avec succès')
      loadPrestataires()
    } catch (error) {
      toast.error('Erreur lors de la suppression')
    }
  }
}

const openModal = () => {
  if (!addModalInstance) {
    addModalInstance = new Modal(addModal.value)
  }
  addModalInstance.show()
}

const closeModal = () => {
  if (addModalInstance) {
    addModalInstance.hide()
  }
  editingPrestataire.value = null
}

const handleSubmit = async (formData) => {
  try {
    if (editingPrestataire.value) {
      await prestatairesAPI.update(editingPrestataire.value.id, formData)
      toast.success('Prestataire modifié avec succès')
    } else {
      await prestatairesAPI.create(formData)
      toast.success('Prestataire ajouté avec succès')
    }
    closeModal()
    loadPrestataires()
  } catch (error) {
    toast.error('Erreur lors de l\'enregistrement')
  }
}

function debounce(func, wait) {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

onMounted(() => {
  loadResidences()
  loadPrestataires()

  nextTick(() => {
    const modalElement = document.getElementById('addModal')
    if (modalElement) {
      addModalInstance = new Modal(modalElement)
    }
  })
})
</script>

<style scoped>
.prestataires-container {
  padding: 20px;
}

.page-header {
  background: linear-gradient(135deg, #fd7e14 0%, #e67e22 100%);
  color: white;
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.page-title {
  font-weight: 700;
  margin: 0;
}
</style>
```

#### `src/components/prestataires/PrestataireCard.vue`

```vue
<template>
  <div class="prestataire-card card h-100">
    <div class="card-body">
      <!-- Header -->
      <div class="d-flex align-items-start mb-3">
        <div class="prestataire-icon me-3">
          <i :class="getServiceIcon(prestataire.service)"></i>
        </div>
        <div class="flex-grow-1">
          <h5 class="card-title mb-1">{{ prestataire.nom }}</h5>
          <span class="badge bg-secondary">{{ getServiceLabel(prestataire.service) }}</span>
        </div>
        <div class="dropdown">
          <button
            class="btn btn-link text-dark p-0"
            data-bs-toggle="dropdown"
          >
            <i class="bi bi-three-dots-vertical"></i>
          </button>
          <ul class="dropdown-menu dropdown-menu-end">
            <li>
              <a class="dropdown-item" href="#" @click.prevent="$emit('view', prestataire)">
                <i class="bi bi-eye me-2"></i>Voir détails
              </a>
            </li>
            <li>
              <a class="dropdown-item" href="#" @click.prevent="$emit('edit', prestataire)">
                <i class="bi bi-pencil me-2"></i>Modifier
              </a>
            </li>
            <li><hr class="dropdown-divider"></li>
            <li>
              <a class="dropdown-item text-danger" href="#" @click.prevent="$emit('delete', prestataire)">
                <i class="bi bi-trash me-2"></i>Supprimer
              </a>
            </li>
          </ul>
        </div>
      </div>

      <!-- Contact Info -->
      <div class="contact-info mb-3">
        <div v-if="prestataire.contact" class="info-item">
          <i class="bi bi-person me-2"></i>
          {{ prestataire.contact }}
        </div>
        <div v-if="prestataire.telephone" class="info-item">
          <i class="bi bi-telephone me-2"></i>
          {{ prestataire.telephone }}
        </div>
        <div v-if="prestataire.email" class="info-item">
          <i class="bi bi-envelope me-2"></i>
          {{ prestataire.email }}
        </div>
      </div>

      <!-- Rate -->
      <div class="rate-info mb-3">
        <label class="text-muted small">Taux horaire</label>
        <div class="rate-value">{{ formatCurrency(prestataire.taux_horaire) }}/h</div>
      </div>

      <!-- Residences -->
      <div v-if="prestataire.residences && prestataire.residences.length > 0" class="residences">
        <label class="text-muted small mb-2">Résidences desservies</label>
        <div class="residence-tags">
          <span
            v-for="res in prestataire.residences"
            :key="res.id"
            class="badge bg-light text-dark me-1 mb-1"
          >
            {{ res.nom }}
          </span>
        </div>
      </div>
    </div>

    <!-- Footer with stats -->
    <div class="card-footer bg-light">
      <div class="row text-center">
        <div class="col-4">
          <div class="stat-value">{{ prestataire.total_factures || 0 }}</div>
          <div class="stat-label">Factures</div>
        </div>
        <div class="col-4">
          <div class="stat-value">{{ prestataire.contrats_actifs || 0 }}</div>
          <div class="stat-label">Contrats</div>
        </div>
        <div class="col-4">
          <div class="stat-value text-success">
            {{ formatCurrency(prestataire.montant_total || 0) }}
          </div>
          <div class="stat-label">Total</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
const props = defineProps({
  prestataire: {
    type: Object,
    required: true,
  },
})

defineEmits(['view', 'edit', 'delete'])

const formatCurrency = (value) => {
  return new Intl.NumberFormat('fr-MA', {
    style: 'currency',
    currency: 'MAD',
  }).format(value)
}

const getServiceIcon = (service) => {
  const icons = {
    ascenseur: 'bi bi-elevator',
    electricite: 'bi bi-lightning',
    plomberie: 'bi bi-droplet',
    jardinage: 'bi bi-tree',
    nettoyage: 'bi bi-brush',
    securite: 'bi bi-shield-check',
    autre: 'bi bi-briefcase',
  }
  return icons[service] || icons.autre
}

const getServiceLabel = (service) => {
  const labels = {
    ascenseur: 'Ascenseur',
    electricite: 'Électricité',
    plomberie: 'Plomberie',
    jardinage: 'Jardinage',
    nettoyage: 'Nettoyage',
    securite: 'Sécurité',
    autre: 'Autre',
  }
  return labels[service] || 'Autre'
}
</script>

<style scoped>
.prestataire-card {
  border: none;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  transition: all 0.3s ease;
  overflow: hidden;
}

.prestataire-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.12);
}

.prestataire-icon {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5rem;
}

.card-title {
  font-weight: 600;
  color: #333;
}

.contact-info {
  font-size: 0.9rem;
  color: #666;
}

.info-item {
  margin-bottom: 5px;
  display: flex;
  align-items: center;
}

.rate-info {
  padding: 10px;
  background-color: #f8f9fa;
  border-radius: 8px;
}

.rate-value {
  font-size: 1.25rem;
  font-weight: 700;
  color: #667eea;
}

.residence-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
}

.card-footer {
  border-top: 2px solid #f0f0f0;
  padding: 15px;
}

.stat-value {
  font-size: 1.1rem;
  font-weight: 700;
  color: #333;
}

.stat-label {
  font-size: 0.75rem;
  color: #6c757d;
  text-transform: uppercase;
}
</style>
```

### 5. Module Assemblées

#### `src/views/assembles/AssembleeList.vue`

```vue
<template>
  <div class="assembles-container">
    <!-- Page Header -->
    <div class="page-header mb-4">
      <div class="row align-items-center">
        <div class="col">
          <h2 class="page-title">
            <i class="bi bi-calendar-event me-2"></i>
            Assemblées Générales
          </h2>
        </div>
        <div class="col-auto">
          <button
            class="btn btn-primary"
            data-bs-toggle="modal"
            data-bs-target="#addModal"
          >
            <i class="bi bi-plus-lg me-2"></i>Nouvelle AG
          </button>
        </div>
      </div>
    </div>

    <!-- Filters -->
    <div class="card mb-4">
      <div class="card-body">
        <div class="row g-3">
          <div class="col-md-4">
            <select v-model="filterResidence" class="form-select" @change="loadAssembles">
              <option value="">Toutes les résidences</option>
              <option v-for="res in residences" :key="res.id" :value="res.id">
                {{ res.nom }}
              </option>
            </select>
          </div>
          <div class="col-md-4">
            <select v-model="filterStatut" class="form-select" @change="loadAssembles">
              <option value="">Tous les statuts</option>
              <option value="planifiee">Planifiée</option>
              <option value="en_cours">En cours</option>
              <option value="terminee">Terminée</option>
              <option value="annulee">Annulée</option>
            </select>
          </div>
          <div class="col-md-4">
            <input
              v-model="filterYear"
              type="number"
              class="form-control"
              placeholder="Année"
              @input="loadAssembles"
            >
          </div>
        </div>
      </div>
    </div>

    <!-- Loading -->
    <LoadingSpinner v-if="loading" />

    <!-- List View -->
    <div v-else class="row g-4">
      <div
        v-for="assemblee in assembles"
        :key="assemblee.id"
        class="col-12"
      >
        <AGCard :assemblee="assemblee" @view="viewDetails" @edit="editAG" />
      </div>
    </div>

    <!-- Add/Edit Modal -->
    <div
      class="modal fade"
      id="addModal"
      tabindex="-1"
      ref="addModal"
    >
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">
              {{ editingAG ? 'Modifier' : 'Nouvelle' }} Assemblée Générale
            </h5>
            <button
              type="button"
              class="btn-close"
              data-bs-dismiss="modal"
            ></button>
          </div>
          <div class="modal-body">
            <AGForm
              :assemblee="editingAG"
              :residences="residences"
              @submit="handleSubmit"
              @cancel="closeModal"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { Modal } from 'bootstrap'
import { assemblesAPI } from '@/api/assembles'
import { residencesAPI } from '@/api/residences'
import AGCard from '@/components/assembles/AGCard.vue'
import AGForm from '@/components/assembles/AGForm.vue'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'
import { useToast } from 'vue-toastification'

const router = useRouter()
const toast = useToast()

const loading = ref(false)
const assembles = ref([])
const residences = ref([])
const filterResidence = ref('')
const filterStatut = ref('')
const filterYear = ref(new Date().getFullYear())
const editingAG = ref(null)
let addModalInstance = null
const addModal = ref(null)

const loadAssembles = async () => {
  loading.value = true
  try {
    const params = {
      residence: filterResidence.value,
      statut: filterStatut.value,
      annee: filterYear.value,
    }

    const response = await assemblesAPI.getList(params)
    assembles.value = response.data.results || response.data
  } catch (error) {
    console.error('Erreur chargement assemblées:', error)
    toast.error('Erreur lors du chargement des assemblées')
  } finally {
    loading.value = false
  }
}

const loadResidences = async () => {
  try {
    const response = await residencesAPI.getList()
    residences.value = response.data.results || response.data
  } catch (error) {
    console.error('Erreur chargement résidences:', error)
  }
}

const viewDetails = (assemblee) => {
  router.push(`/assembles/${assemblee.id}`)
}

const editAG = (assemblee) => {
  editingAG.value = { ...assemblee }
  openModal()
}

const openModal = () => {
  if (!addModalInstance) {
    addModalInstance = new Modal(addModal.value)
  }
  addModalInstance.show()
}

const closeModal = () => {
  if (addModalInstance) {
    addModalInstance.hide()
  }
  editingAG.value = null
}

const handleSubmit = async (formData) => {
  try {
    if (editingAG.value) {
      await assemblesAPI.update(editingAG.value.id, formData)
      toast.success('AG modifiée avec succès')
    } else {
      await assemblesAPI.create(formData)
      toast.success('AG créée avec succès')
    }
    closeModal()
    loadAssembles()
  } catch (error) {
    toast.error('Erreur lors de l\'enregistrement')
  }
}

onMounted(() => {
  loadResidences()
  loadAssembles()

  nextTick(() => {
    const modalElement = document.getElementById('addModal')
    if (modalElement) {
      addModalInstance = new Modal(modalElement)
    }
  })
})
</script>

<style scoped>
.assembles-container {
  padding: 20px;
}

.page-header {
  background: linear-gradient(135deg, #e83e8c 0%, #d63384 100%);
  color: white;
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.page-title {
  font-weight: 700;
  margin: 0;
}
</style>
```

### 6. Module Documents

#### `src/views/documents/DocumentLibrary.vue`

```vue
<template>
  <div class="documents-container">
    <!-- Page Header -->
    <div class="page-header mb-4">
      <div class="row align-items-center">
        <div class="col">
          <h2 class="page-title">
            <i class="bi bi-file-earmark-text me-2"></i>
            Bibliothèque de Documents
          </h2>
        </div>
        <div class="col-auto">
          <button
            class="btn btn-primary"
            data-bs-toggle="modal"
            data-bs-target="#uploadModal"
          >
            <i class="bi bi-upload me-2"></i>Uploader
          </button>
        </div>
      </div>
    </div>

    <!-- Filters & Search -->
    <div class="card mb-4">
      <div class="card-body">
        <div class="row g-3">
          <div class="col-md-4">
            <input
              v-model="searchQuery"
              type="text"
              class="form-control"
              placeholder="Rechercher des documents..."
              @input="handleSearch"
            >
          </div>
          <div class="col-md-3">
            <select v-model="filterCategory" class="form-select" @change="loadDocuments">
              <option value="">Toutes les catégories</option>
              <option value="reglement">Règlement</option>
              <option value="pv">Procès-verbaux</option>
              <option value="facture">Factures</option>
              <option value="contrat">Contrats</option>
              <option value="budget">Budgets</option>
              <option value="autre">Autre</option>
            </select>
          </div>
          <div class="col-md-3">
            <select v-model="filterResidence" class="form-select" @change="loadDocuments">
              <option value="">Toutes les résidences</option>
              <option v-for="res in residences" :key="res.id" :value="res.id">
                {{ res.nom }}
              </option>
            </select>
          </div>
          <div class="col-md-2">
            <button class="btn btn-outline-secondary w-100" @click="resetFilters">
              <i class="bi bi-x-circle me-1"></i>Réinitialiser
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Loading -->
    <LoadingSpinner v-if="loading" />

    <!-- Documents Grid -->
    <div v-else>
      <!-- Category Tabs -->
      <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
          <a
            class="nav-link"
            :class="{ active: activeCategory === '' }"
            href="#"
            @click.prevent="activeCategory = ''; loadDocuments()"
          >
            Tous
          </a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link"
            :class="{ active: activeCategory === 'reglement' }"
            href="#"
            @click.prevent="activeCategory = 'reglement'; loadDocuments()"
          >
            Règlements
          </a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link"
            :class="{ active: activeCategory === 'pv' }"
            href="#"
            @click.prevent="activeCategory = 'pv'; loadDocuments()"
          >
            PV
          </a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link"
            :class="{ active: activeCategory === 'facture' }"
            href="#"
            @click.prevent="activeCategory = 'facture'; loadDocuments()"
          >
            Factures
          </a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link"
            :class="{ active: activeCategory === 'contrat' }"
            href="#"
            @click.prevent="activeCategory = 'contrat'; loadDocuments()"
          >
            Contrats
          </a>
        </li>
      </ul>

      <!-- Documents Grid -->
      <div v-if="documents.length > 0" class="row g-4">
        <div
          v-for="document in documents"
          :key="document.id"
          class="col-md-6 col-lg-4"
        >
          <DocumentCard
            :document="document"
            @download="downloadDocument"
            @delete="deleteDocument"
          />
        </div>
      </div>

      <!-- Empty State -->
      <div v-else class="text-center py-5">
        <i class="bi bi-folder-x text-muted" style="font-size: 4rem;"></i>
        <h4 class="mt-3">Aucun document trouvé</h4>
        <p class="text-muted">Essayez de modifier vos filtres ou uploadez un nouveau document</p>
      </div>

      <!-- Pagination -->
      <div v-if="pagination.totalPages > 1" class="d-flex justify-content-center mt-4">
        <nav>
          <ul class="pagination">
            <li class="page-item" :class="{ disabled: pagination.page === 1 }">
              <a
                class="page-link"
                href="#"
                @click.prevent="changePage(pagination.page - 1)"
              >
                <i class="bi bi-chevron-left"></i>
              </a>
            </li>
            <li
              v-for="page in pagination.totalPages"
              :key="page"
              class="page-item"
              :class="{ active: page === pagination.page }"
            >
              <a
                class="page-link"
                href="#"
                @click.prevent="changePage(page)"
              >
                {{ page }}
              </a>
            </li>
            <li class="page-item" :class="{ disabled: pagination.page === pagination.totalPages }">
              <a
                class="page-link"
                href="#"
                @click.prevent="changePage(pagination.page + 1)"
              >
                <i class="bi bi-chevron-right"></i>
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </div>

    <!-- Upload Modal -->
    <div
      class="modal fade"
      id="uploadModal"
      tabindex="-1"
      ref="uploadModal"
    >
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Uploader un document</h5>
            <button
              type="button"
              class="btn-close"
              data-bs-dismiss="modal"
            ></button>
          </div>
          <div class="modal-body">
            <UploadDocument
              :residences="residences"
              @upload="handleUpload"
              @cancel="closeUploadModal"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue'
import { Modal } from 'bootstrap'
import { documentsAPI } from '@/api/documents'
import { residencesAPI } from '@/api/residences'
import DocumentCard from '@/components/documents/DocumentCard.vue'
import UploadDocument from '@/components/documents/UploadDocument.vue'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'
import { useToast } from 'vue-toastification'

const toast = useToast()

const loading = ref(false)
const documents = ref([])
const residences = ref([])
const searchQuery = ref('')
const filterCategory = ref('')
const filterResidence = ref('')
const activeCategory = ref('')
const pagination = ref({
  page: 1,
  totalPages: 1,
  total: 0,
})
let uploadModalInstance = null
const uploadModal = ref(null)

const loadDocuments = async () => {
  loading.value = true
  try {
    const params = {
      page: pagination.value.page,
      search: searchQuery.value,
      category: filterCategory.value || activeCategory.value,
      residence: filterResidence.value,
    }

    const response = await documentsAPI.getList(params)
    documents.value = response.data.results || response.data
    pagination.value = {
      page: response.data.page || 1,
      totalPages: Math.ceil((response.data.count || response.data.length) / (response.data.page_size || 12)),
      total: response.data.count || response.data.length,
    }
  } catch (error) {
    console.error('Erreur chargement documents:', error)
    toast.error('Erreur lors du chargement des documents')
  } finally {
    loading.value = false
  }
}

const loadResidences = async () => {
  try {
    const response = await residencesAPI.getList()
    residences.value = response.data.results || response.data
  } catch (error) {
    console.error('Erreur chargement résidences:', error)
  }
}

const handleSearch = debounce(() => {
  pagination.value.page = 1
  loadDocuments()
}, 500)

const changePage = (page) => {
  if (page >= 1 && page <= pagination.value.totalPages) {
    pagination.value.page = page
    loadDocuments()
  }
}

const resetFilters = () => {
  searchQuery.value = ''
  filterCategory.value = ''
  filterResidence.value = ''
  activeCategory.value = ''
  pagination.value.page = 1
  loadDocuments()
}

const downloadDocument = async (document) => {
  try {
    const response = await documentsAPI.download(document.id)
    const url = window.URL.createObjectURL(new Blob([response.data]))
    const link = document.createElement('a')
    link.href = url
    link.setAttribute('download', document.nom_fichier)
    document.body.appendChild(link)
    link.click()
    link.remove()
    toast.success('Téléchargement démarré')
  } catch (error) {
    toast.error('Erreur lors du téléchargement')
  }
}

const deleteDocument = async (document) => {
  try {
    await documentsAPI.delete(document.id)
    toast.success('Document supprimé avec succès')
    loadDocuments()
  } catch (error) {
    toast.error('Erreur lors de la suppression')
  }
}

const handleUpload = async (formData) => {
  try {
    await documentsAPI.upload(formData)
    toast.success('Document uploadé avec succès')
    closeUploadModal()
    loadDocuments()
  } catch (error) {
    toast.error('Erreur lors de l\'upload')
  }
}

const closeUploadModal = () => {
  if (uploadModalInstance) {
    uploadModalInstance.hide()
  }
}

function debounce(func, wait) {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

onMounted(() => {
  loadResidences()
  loadDocuments()

  nextTick(() => {
    const modalElement = document.getElementById('uploadModal')
    if (modalElement) {
      uploadModalInstance = new Modal(modalElement)
    }
  })
})
</script>

<style scoped>
.documents-container {
  padding: 20px;
}

.page-header {
  background: linear-gradient(135deg, #17a2b8 0%, #138496 100%);
  color: white;
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.page-title {
  font-weight: 700;
  margin: 0;
}

.nav-tabs .nav-link {
  color: #495057;
  font-weight: 500;
}

.nav-tabs .nav-link.active {
  color: #17a2b8;
  border-color: #17a2b8 #17a2b8 #fff;
}
</style>
```

---

## Router Configuration

### `src/router/index.js`

```javascript
import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const routes = [
  {
    path: '/',
    name: 'home',
    redirect: '/dashboard',
    meta: { requiresAuth: true },
  },
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/auth/Login.vue'),
    meta: { layout: 'AuthLayout' },
  },
  {
    path: '/register',
    name: 'register',
    component: () => import('@/views/auth/Register.vue'),
    meta: { layout: 'AuthLayout' },
  },
  {
    path: '/dashboard',
    name: 'dashboard',
    component: () => import('@/views/dashboard/Dashboard.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/residences',
    name: 'residences',
    component: () => import('@/views/residences/ResidenceList.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/residences/:id',
    name: 'residence-detail',
    component: () => import('@/views/residences/ResidenceDetail.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/coproprietaires',
    name: 'coproprietaires',
    component: () => import('@/views/coproprietaires/CoproprietaireList.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/coproprietaires/:id',
    name: 'coproprietaire-detail',
    component: () => import('@/views/coproprietaires/CoproprietaireDetail.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/finances',
    name: 'finances',
    component: () => import('@/views/finances/Finances.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/prestataires',
    name: 'prestataires',
    component: () => import('@/views/prestataires/PrestataireList.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/prestataires/:id',
    name: 'prestataire-detail',
    component: () => import('@/views/prestataires/PrestataireDetail.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/assembles',
    name: 'assembles',
    component: () => import('@/views/assembles/AssembleeList.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/assembles/:id',
    name: 'assemblee-detail',
    component: () => import('@/views/assembles/AssembleeDetail.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/documents',
    name: 'documents',
    component: () => import('@/views/documents/DocumentLibrary.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/rapports',
    name: 'rapports',
    component: () => import('@/views/rapports/Rapports.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/profile',
    name: 'profile',
    component: () => import('@/views/Profile.vue'),
    meta: { requiresAuth: true },
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'not-found',
    component: () => import('@/views/NotFound.vue'),
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition
    } else {
      return { top: 0 }
    }
  },
})

// Navigation guards
router.beforeEach((to, from, next) => {
  const authStore = useAuthStore()

  if (to.meta.requiresAuth && !authStore.isAuthenticated) {
    next('/login')
  } else if ((to.name === 'login' || to.name === 'register') && authStore.isAuthenticated) {
    next('/dashboard')
  } else {
    next()
  }
})

export default router
```

---

## Store Configuration

### `src/stores/auth.js`

```javascript
import { defineStore } from 'pinia'
import { authAPI } from '@/api/auth'
import { useToast } from 'vue-toastification'

export const useAuthStore = defineStore('auth', {
  state: () => ({
    user: null,
    token: localStorage.getItem('access_token') || null,
    refreshToken: localStorage.getItem('refresh_token') || null,
    loading: false,
  }),

  getters: {
    isAuthenticated: (state) => !!state.token,
    userFullName: (state) => {
      if (!state.user) return ''
      return `${state.user.first_name} ${state.user.last_name}`
    },
  },

  actions: {
    async login(credentials) {
      this.loading = true
      try {
        const response = await authAPI.login(credentials)
        this.token = response.data.access
        this.refreshToken = response.data.refresh
        this.user = response.data.user

        localStorage.setItem('access_token', this.token)
        localStorage.setItem('refresh_token', this.refreshToken)

        return true
      } catch (error) {
        throw error
      } finally {
        this.loading = false
      }
    },

    async logout() {
      try {
        await authAPI.logout()
      } catch (error) {
        console.error('Logout error:', error)
      } finally {
        this.user = null
        this.token = null
        this.refreshToken = null
        localStorage.removeItem('access_token')
        localStorage.removeItem('refresh_token')
      }
    },

    async fetchUser() {
      if (!this.token) return

      try {
        const response = await authAPI.getCurrentUser()
        this.user = response.data
      } catch (error) {
        console.error('Fetch user error:', error)
        if (error.response?.status === 401) {
          this.logout()
        }
      }
    },

    async refreshTokenAction() {
      if (!this.refreshToken) {
        this.logout()
        return false
      }

      try {
        const response = await authAPI.refreshToken(this.refreshToken)
        this.token = response.data.access
        localStorage.setItem('access_token', this.token)
        return true
      } catch (error) {
        this.logout()
        return false
      }
    },
  },
})
```

---

## Environment Configuration

### `.env`

```bash
# API Configuration
VITE_API_URL=http://localhost:8000/api

# Application
VITE_APP_NAME=SyndicPro
VITE_APP_VERSION=1.0.0

# Features
VITE_ENABLE_CHAT=true
VITE_ENABLE_NOTIFICATIONS=true
```

### `.env.example`

```bash
# API Configuration
VITE_API_URL=http://localhost:8000/api

# Application
VITE_APP_NAME=SyndicPro
VITE_APP_VERSION=1.0.0

# Features
VITE_ENABLE_CHAT=true
VITE_ENABLE_NOTIFICATIONS=true
```

---

## Package Configuration

### `package.json`

```json
{
  "name": "syndic-frontend",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview",
    "lint": "eslint . --ext .vue,.js,.jsx,.cjs,.mjs --fix --ignore-path .gitignore"
  },
  "dependencies": {
    "axios": "^1.6.2",
    "bootstrap": "^5.3.2",
    "bootstrap-icons": "^1.11.3",
    "@popperjs/core": "^2.11.8",
    "dayjs": "^1.11.10",
    "pinia": "^2.1.7",
    "sweetalert2": "^11.10.3",
    "vue": "^3.3.11",
    "vue-router": "^4.2.5",
    "vue-toastification": "^2.0.0-rc.5",
    "@vueuse/core": "^10.7.0"
  },
  "devDependencies": {
    "@vitejs/plugin-vue": "^4.5.2",
    "vite": "^5.0.8",
    "eslint": "^8.55.0",
    "eslint-plugin-vue": "^9.19.2"
  }
}
```

---

## Utils

### `src/utils/formatters.js`

```javascript
import dayjs from 'dayjs'
import 'dayjs/locale/fr'

dayjs.locale('fr')

export const formatCurrency = (amount, currency = 'MAD') => {
  return new Intl.NumberFormat('fr-MA', {
    style: 'currency',
    currency,
  }).format(amount)
}

export const formatDate = (date, format = 'DD/MM/YYYY') => {
  return dayjs(date).format(format)
}

export const formatDateTime = (date) => {
  return dayjs(date).format('DD/MM/YYYY HH:mm')
}

export const formatRelativeTime = (date) => {
  return dayjs(date).fromNow()
}

export const formatPhoneNumber = (phone) => {
  if (!phone) return ''
  const cleaned = phone.replace(/\D/g, '')
  const match = cleaned.match(/^(\d{2})(\d{3})(\d{3})$/)
  if (match) {
    return `${match[1]} ${match[2]} ${match[3]}`
  }
  return phone
}

export const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 Bytes'
  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i]
}

export const truncateText = (text, length = 100) => {
  if (!text) return ''
  if (text.length <= length) return text
  return text.substring(0, length) + '...'
}
```

### `src/utils/constants.js`

```javascript
export const STATUT_COPROPRIETAIRE = {
  ACTIF: 'actif',
  INACTIF: 'inactif',
}

export const STATUT_ASSEMBLEE = {
  PLANIFIEE: 'planifiee',
  EN_COURS: 'en_cours',
  TERMINEE: 'terminee',
  ANNULEE: 'annulee',
}

export const TYPE_PRESTATAIRE = {
  ASCENSEUR: 'ascenseur',
  ELECTRICITE: 'electricite',
  PLOMBERIE: 'plomberie',
  JARDINAGE: 'jardinage',
  NETTOYAGE: 'nettoyage',
  SECURITE: 'securite',
  AUTRE: 'autre',
}

export const CATEGORIE_DOCUMENT = {
  REGLEMENT: 'reglement',
  PV: 'pv',
  FACTURE: 'facture',
  CONTRAT: 'contrat',
  BUDGET: 'budget',
  AUTRE: 'autre',
}

export const MODE_PAIEMENT = {
  VIREMENT: 'virement',
  CHEQUE: 'cheque',
  ESPECES: 'especes',
  TERMINAL: 'terminal',
  PRELEVEMENT: 'prelevement',
}

export const STATUT_FACTURE = {
  EN_ATTENTE: 'en_attente',
  PAYEE: 'payee',
  ANNULEE: 'annulee',
}

export const STATUT_COTISATION = {
  EN_ATTENTE: 'en_attente',
  PARTIELLEMENT_PAYEE: 'partiellement_payee',
  PAYEE: 'payee',
  EN_RETARD: 'en_retard',
}
```

---

## Déploiement

### Build pour production

```bash
# Installer les dépendances
npm install

# Build
npm run build

# Preview en local
npm run preview
```

### Déploiement sur Vercel

1. Installer Vercel CLI:
```bash
npm install -g vercel
```

2. Déployer:
```bash
vercel
```

### Déploiement sur Netlify

1. Build command:
```bash
npm run build
```

2. Publish directory:
```
dist
```

3. Environment variables:
```
VITE_API_URL=https://your-api-url.com/api
```

### Configuration Nginx (pour déploiement custom)

```nginx
server {
    listen 80;
    server_name your-domain.com;

    root /var/www/syndic-frontend/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
}
```

---

## Conclusion

Ce guide complet vous fournit tout ce dont vous avez besoin pour créer le frontend Vue.js de votre application de gestion de syndic multi-résidences. Chaque composant est conçu pour être:

- **Responsive**: Fonctionne sur mobile, tablette et desktop
- **User-friendly**: Interface intuitive et moderne
- **Accessible**: Conforme aux standards d'accessibilité
- **Maintenable**: Code organisé et bien structuré
- **Extensible**: Facile à étendre avec de nouvelles fonctionnalités

### Prochaines étapes recommandées:

1. Créer les composants manquants (FinanceChart, RecentActivity, etc.)
2. Implémenter les pages de détail
3. Ajouter les tests unitaires
4. Configurer CI/CD
5. Optimiser les performances (lazy loading, code splitting)

Pour toute question ou besoin d'aide supplémentaire, n'hésitez pas à consulter la documentation officielle de [Vue.js](https://vuejs.org/) et [Bootstrap](https://getbootstrap.com/).
